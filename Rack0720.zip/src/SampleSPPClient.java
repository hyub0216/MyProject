import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.Vector;

import javax.bluetooth.DiscoveryListener;
import javax.bluetooth.LocalDevice;
import javax.bluetooth.RemoteDevice;
import javax.microedition.io.Connector;
import javax.microedition.io.StreamConnection;

import com.pi4j.io.gpio.GpioPinDigitalInput;
import com.pi4j.io.gpio.GpioPinDigitalOutput;
import com.pi4j.io.gpio.Pin;
import com.pi4j.io.gpio.RaspiPin;

import com.pi4j.io.gpio.GpioController;
import com.pi4j.io.gpio.GpioFactory;
import com.pi4j.io.gpio.GpioPinDigitalInput;
import com.pi4j.io.gpio.GpioPinDigitalOutput;
import com.pi4j.io.gpio.Pin;
import com.pi4j.io.gpio.PinState;
import com.pi4j.io.gpio.RaspiPin;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Vector;
import javax.bluetooth.*;

public class SampleSPPClient {
	BluetoothManager bm = null;
	private final static boolean DISPLAY_DIGIT = false;
	// Note: "Mismatch" 23-24. The wiring says DOUT->#23, DIN->#24
	// 23: DOUT on the ADC is IN on the GPIO. ADC:Slave, GPIO:Master
	// 24: DIN on the ADC, OUT on the GPIO. Same reason as above.
	// SPI: Serial Peripheral Interface

	private static Pin spiClk = RaspiPin.GPIO_14; // Pin #18, clock
	private static Pin spiMiso = RaspiPin.GPIO_13; // Pin #23, data in. MISO:
													// Master In Slave Out
	private static Pin spiMosi = RaspiPin.GPIO_12; // Pin #24, data out. MOSI:
													// Master Out Slave In
	private static Pin spiCs = RaspiPin.GPIO_10; // Pin #25, Chip Select

	private static GpioPinDigitalInput misoInput = null;
	private static GpioPinDigitalOutput mosiOutput = null;
	private static GpioPinDigitalOutput clockOutput = null;
	private static GpioPinDigitalOutput chipSelectOutput = null;
	private static final int light_channel = 0;
	private static final int temp_channel = 1;
	private static double temperature;
	private static double light;
	private static final String LACK_NAME = "LACK01";
	private static Vector devices;

	private static double ConvertTemp(double data) {
		double temp;
		temp = Math.round((((data * 330) / (1023)) - 50) * 100d) / 100d;
		return temp;
	}

	private static double ConvertVolt(double data) {
		double temp;
		temp = Math.round(((data * 3.3) / (1023)) * 100d) / 100d;
		return temp;
	}

	private static int readAdc(int channel) {
		chipSelectOutput.high();

		clockOutput.low();
		chipSelectOutput.low();

		int adccommand = channel;
		adccommand |= 0x18; // 0x18: 00011000
		adccommand <<= 3;
		for (int i = 0; i < 5; i++) //
		{
			if ((adccommand & 0x80) != 0x0) // 0x80 = 0&10000000
				mosiOutput.high();
			else
				mosiOutput.low();
			adccommand <<= 1;
			clockOutput.high();
			clockOutput.low();
		}

		int adcOut = 0;
		for (int i = 0; i < 12; i++) // Read in one empty bit, one null bit and
										// 10 ADC bits
		{
			clockOutput.high();
			clockOutput.low();
			adcOut <<= 1;

			if (misoInput.isHigh()) {
				adcOut |= 0x1;
			}
			if (DISPLAY_DIGIT)
				System.out.println("ADCOUT: 0x"
						+ Integer.toString(adcOut, 16).toUpperCase() + ", 0&"
						+ Integer.toString(adcOut, 2).toUpperCase());
		}
		chipSelectOutput.high();

		adcOut >>= 1; // Drop first bit
		return adcOut;
	}

	public static void main(String args[]) throws IOException, InterruptedException {
		String mConnect = null;
		
		GpioController gpio = GpioFactory.getInstance();
		GpioPinDigitalOutput pin1 = gpio
				.provisionDigitalOutputPin(RaspiPin.GPIO_05);
		GpioPinDigitalOutput pin2 = gpio
				.provisionDigitalOutputPin(RaspiPin.GPIO_04);
		mosiOutput = gpio.provisionDigitalOutputPin(spiMosi, "MOSI",
				PinState.LOW);
		clockOutput = gpio.provisionDigitalOutputPin(spiClk, "CLK",
				PinState.LOW);
		chipSelectOutput = gpio.provisionDigitalOutputPin(spiCs, "CS",
				PinState.LOW);

		misoInput = gpio.provisionDigitalInputPin(spiMiso, "MISO");

		Runtime.getRuntime().addShutdownHook(new Thread() {
			public void run() {
				System.out.println("Shutting down.");
			}
		});
		
		mConnect = 
				"btspp://"
//				+ device.getBluetoothAddress()//
				+"001F81000830"
				+ ":2";
		
		//Header + service_type
		byte[] serviceType={0x50, 0x41, 0x43, 0x4B, 0x24, 0x02};

		try {
			StreamConnection conn = (StreamConnection) Connector.open(mConnect);

			System.out.println("Connected:" + mConnect);

			BufferedReader in = new BufferedReader(new InputStreamReader(
					conn.openInputStream()));
			PrintStream out = new PrintStream(conn.openOutputStream());

			while (true) {
				double tempadc = readAdc(temp_channel);
				double lightadc = readAdc(light_channel);
				temperature = ConvertTemp(tempadc);
				light = ConvertVolt(lightadc);

				StringBuilder sb = new StringBuilder();
				sb.append("{\"Type\":\"LackData\",\"Lack_id\":\"");
				sb.append(LACK_NAME);
				sb.append("\",\"Sensors_data\":[ {\"Temp\":\"");
				sb.append(temperature);
				sb.append("\"},{\"Light\":\"");
				sb.append(light);
				sb.append("\"}]}");
				out.println(sb.toString());
				String data = in.readLine(); // Read echo

				System.out.println(data);
				if (!data.equals("got_msg")) {
					String act_id = data.split(",")[0];
					String value = data.split(",")[1];
					if (act_id.equals("act1") && value.equals("on")) {
						pin1.high();
					} else if (act_id.equals("act2") && value.equals("on")) {
						pin2.high();
					} else if (value.equals("off")) {
						pin1.low();
						pin2.low();
					}
				}
				Thread.sleep(2000);
				if (data.equals("exit"))
					break;
			}
			 in.close();
			 out.close();
			conn.close();
		} catch (Exception e) {
			System.out.print(e.toString());
			System.out.println("connection failed");
		}
	}

}
