import java.awt.Label;
import java.io.IOException;
import java.util.Vector;

import javax.bluetooth.BluetoothStateException;
import javax.bluetooth.DeviceClass;
import javax.bluetooth.DiscoveryAgent;
import javax.bluetooth.DiscoveryListener;
import javax.bluetooth.LocalDevice;
import javax.bluetooth.RemoteDevice;
import javax.bluetooth.ServiceRecord;

public class BluetoothManager {

	private static final String LACK_ID = "TG";
	private static RemoteDevice devicesDiscovered;
	private static String name = null;

	public static RemoteDevice discoverDevices() {

		final Object inquiryCompletedEvent = new Object();
		DiscoveryListener listener = new DiscoveryListener() {

			public void deviceDiscovered(RemoteDevice btDevice, DeviceClass cod) {
				try {
					name = btDevice.getFriendlyName(false);
				} catch (IOException e) {
					System.out.println("Can not get device's name");
				}
				if(name.equals(LACK_ID))
					devicesDiscovered=btDevice;
			}

			public void inquiryCompleted(int discType) {
				System.out.println("Device Inquiry completed!");
				synchronized (inquiryCompletedEvent) {
					inquiryCompletedEvent.notifyAll();
				}
			}
			public void serviceSearchCompleted(int transID, int respCode) {
			}
			public void servicesDiscovered(int transID,
					ServiceRecord[] servRecord) {
			}
		};
		synchronized (inquiryCompletedEvent) {

			boolean started = false;

			while (!started ) {
				try {
					started = LocalDevice.getLocalDevice().getDiscoveryAgent()
							.startInquiry(DiscoveryAgent.GIAC, listener);
					if (started) {
						System.out
								.println("wait for device inquiry to complete...");
						inquiryCompletedEvent.wait();
					}
				} catch (Exception e) {
					started = false;
				}
			}

		}
		return devicesDiscovered;
	}
}
