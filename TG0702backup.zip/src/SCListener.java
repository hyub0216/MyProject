import java.io.IOException;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.json.simple.parser.ParseException;

import com.espertech.esper.client.EPStatement;

/**
 * @author Smart-cloud Listener This class can make Thin-Gateway get Msg from
 *         Smart-cloud using LAN
 */
public class SCListener implements Runnable {
	
	private static int i=0;

	private PushListener ps = null;
	private static final String TG_ID = "TG01";
	private static final String TOPIC_EPL = "EPL";
	private static final String TOPIC_ACTUATOR = "ACT";
	private static String Key_value = null;
	static SCListener SC = null;
	private static MsgParser msgParser = null;
	private static StringBuilder EPL = new StringBuilder();
	private static StringBuilder ACT = new StringBuilder();
	private static MQTT mqtt = null;
	private static Security tempSecurity = new Security();
	
	public SCListener() throws IOException {
	}

	public static SCListener getInstance() {
		if (SC == null) {
			try {
				msgParser = new MsgParser();
				SC = new SCListener();
				tempSecurity = new Security();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return SC;
	}

	public void SetCodedTopic(String topic) {
		Key_value = topic;
	}

	public String GetTG_ID() {
		return TG_ID;
	}
	// Input the event based on event type
	public void inputEvent(String msg, boolean IsDB) {
		String epl = null;
		try {
			System.out.println("msg : " + msg);
			// set message in msgParserW
			msgParser.SetMsg(msg);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			System.out.println("Parser Error! " + e1.toString());
		}
		System.out.println("Input EPL : " + msgParser.getEPL().toString());
		try {

			// get event from JSON
			String event_num = msgParser.getEvent_num();
			// get EPL from JSON
			epl = msgParser.getEPL();
			String listenerType = msgParser.getListenerType();

			// get EPL named event_num
			EPStatement stateEPL = EventManager.getInstance().getStatement(
					event_num);
			// if EPL named event_num is already exist
			if (stateEPL != null) {
				System.out.println("delete an overlapped statement - "
						+ event_num);
				TG_DB.getInstance().RemoveEvent(event_num);
				// stop and delete previous EPL
				stateEPL.stop();
				stateEPL.destroy();
				stateEPL = null;
			} else
				System.out.println("- EPL is new");
			
			if(!IsDB)
			{
				TG_DB.getInstance().StoreEPL(event_num, msg);
				TG_DB.getInstance().CloseDB();
			}

			// renew EPL named event_num
			stateEPL = EventManager.getInstance().CreateNewEPL(epl, event_num);
			System.out.println("create the statement - " + event_num);

			// Check Event Type
			if (listenerType.equals("Push")) {
				String push_type = msgParser.getPushType();
				ps = new PushListener(push_type);
				stateEPL.addListener(ps);
				System.out.println("new Push event is registered");

				// send log to SC *** Error occur
				MQTT.getInstance().publishLog(
						"new push event ( " + epl + " ) is registered", "11");
			} else {
				String act_id = msgParser.getAct_id();
				String act_value = msgParser.getAct_value();
				StringBuilder sb = new StringBuilder();
				sb.append(act_id);
				sb.append(",");
				sb.append(act_value);
				stateEPL.addListener(new ActuatorListener(sb.toString()));
				System.out.println("new Actuator event is registered");

				// send log to SC *** Error occur
				MQTT.getInstance().publishLog(
						"new actuator event ( " + epl + " ) is registered",
						"11");
			}

		} catch (Exception e) {
			System.out.println("Error failed add EPL - "
					+ e.getLocalizedMessage());
		}
	}

	// Execute Actuator
	public void doAction(String msg) throws ParseException {
		MsgParser parser = new MsgParser();
		parser.SetMsg(msg);
		String act_id = parser.getAct_id();
		String act_value = parser.getAct_value();
		System.out.println("Actvalue: " + act_value);
		System.out.println("Actuator Start");
		// we are supposed to send this Msg to Actuator, but we haven't decided
		// which protocol use yet.
		// It't for just test
		StringBuilder sb = new StringBuilder();
		sb.append(act_id);
		sb.append(",");
		sb.append(act_value);
		ActuatorList.getInstance().sendActMsg(sb.toString());
		MQTT.getInstance().publishLog("Actuator is " + act_value, "21");
	}

	public void SetTopic() {
		EPL.append(Key_value);
		EPL.append("/");
		EPL.append(TOPIC_EPL);
		EPL.append("/");
		EPL.append(TG_ID);
		ACT.append(Key_value);
		ACT.append("/");
		ACT.append(TOPIC_ACTUATOR);
		ACT.append("/");
		ACT.append(TG_ID);

	}

	private static MqttClient mqttclnt = null;

	public void run() {
		mqtt = MQTT.getInstance();
		mqttclnt = mqtt.getMQTTclient();
		// Receive Key_value from SC
		Key_value = TG_DB.getInstance().GetKeyValue();
		if (Key_value == null) {
			System.out.println("Waiting for Topic......");
			try {
				Thread.sleep(1000);
//				GetTopic(TG_ID, mqttclnt);
				GetData(TG_ID, mqttclnt);
			} catch (Exception e) {
				e.printStackTrace();
			}
			while (mqtt.getGotTopic()) {
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			try {
				mqttclnt.unsubscribe(TG_ID);
			} catch (MqttException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} else {
			mqtt.SetKeyValue(Key_value);
			SetTopic();
			mqtt.publishLog("Key value in DB is added ", "12");
		}
		mqttclnt.setCallback(new MqttCallback(){
			// Overriding messageArrived
			public void messageArrived(String topic, MqttMessage msg)
					throws Exception {
				if (topic.equals(EPL.toString())) {
					inputEvent(msg.toString(),false);
				} else if (topic.equals(ACT.toString())) {
					doAction(msg.toString());
				}
			}

			public void deliveryComplete(IMqttDeliveryToken arg0) {
			}

			public void connectionLost(Throwable arg0) {
			}
		});
		try {
			// Receive data from Topic : EPL and ACT
			mqttclnt.subscribe(EPL.toString());
			mqttclnt.subscribe(ACT.toString());
		} catch (MqttException e2) {
			e2.printStackTrace();
		}
		while (true) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	// Get Topic(Key_value) from SC
	public void SetTopicFromJson(String msg)
	{
		MsgParser parser = new MsgParser();
		try {
			parser.SetMsg(msg);
		} catch (ParseException e) {
			System.out.println("error - parsing");
		}
		Key_value=parser.getTopic();
		
		System.out.println("setting ..... new topic : "+Key_value);
		
		TG_DB.getInstance().StoreKeyValue(Key_value);
		TG_DB.getInstance().CloseDB();
		SetTopic();
		mqtt.SetKeyValue(Key_value);
		mqtt.setGotTopic();
		mqtt.publishLog("New_key(" +Key_value +")is added", "12");
	}
	
	
	public void GetData(final String Newtopic, final MqttClient clnt)
			throws MqttException {
		clnt.setCallback(new MqttCallback() {
			public void messageArrived(String topic, MqttMessage msg)
					throws Exception {
				
				MsgParser msgTemp = new MsgParser();
				msgTemp.SetMsg(msg.toString());
				System.out.println("Topic : " +topic + " message : "+msg.toString() +"count : "+i++);
				byte[] bytes;
				bytes = msgTemp.getJsonBinary();
				
				//if datatype is 01 then It is about Topic
				if(msgTemp.getdataType().equals("01"))
				{
					String temp = null;
					temp = tempSecurity.GetJsonMsg(bytes);
					SetTopicFromJson(temp);
				}
				else if(msgTemp.getdataType().equals("00"))
					tempSecurity.GetShaKeyFromSC(bytes);
				else if(msgTemp.getdataType().equals("03"))
				{
					System.out.println("ignoring...");
				}
				
			}

			public void deliveryComplete(IMqttDeliveryToken arg0) {
			}

			public void connectionLost(Throwable arg0) {
				arg0.printStackTrace();
			}
		});

		clnt.subscribe(Newtopic);

	}
	
}
