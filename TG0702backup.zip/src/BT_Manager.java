import java.io.IOException;

import javax.bluetooth.BluetoothStateException;
import javax.bluetooth.DiscoveryAgent;
import javax.bluetooth.LocalDevice;
import javax.bluetooth.RemoteDevice;
import javax.bluetooth.UUID;
import javax.microedition.io.Connector;
import javax.microedition.io.StreamConnection;
import javax.microedition.io.StreamConnectionNotifier;

/**
 * @author
 */
public class BT_Manager implements Runnable {

	// Bluetooth basic setting
	private StreamConnectionNotifier service;
	private UUID SERVER_ID;
	private String url;
	private StreamConnection conn;

	// to add new sensor Data

	public BT_Manager() throws IOException {
		SERVER_ID = new UUID("BAE0D0C0B0A00095570605040302011", false);
		url = "btspp://localhost:" + SERVER_ID.toString() + ";name=echoService";
		try {
			LocalDevice.getLocalDevice().setDiscoverable(DiscoveryAgent.GIAC);
		} catch (BluetoothStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.toString());
		}
		service = (StreamConnectionNotifier) Connector.open(url);
	}

	// continuously connect to several Lack
	public void run() {

		try {

			// should need Security in Connection part;
			while (true) {
				System.out.println("Waiting for connection from Lack");
				conn = (StreamConnection) service.acceptAndOpen();
				System.out.println("Lack is successfully connected");
				RemoteDevice dev = RemoteDevice.getRemoteDevice(conn);
				if (dev.getBluetoothAddress() != null) {
					System.out.println("+++++++++ connected ++++++++");
					System.out.println("Device Address : "
							+ dev.getBluetoothAddress());
					System.out.println("Device name : "
							+ dev.getFriendlyName(true));

					StreamConnection conn2 = conn;
					ThreadPool.getInstance().runWorker(
							dev.getBluetoothAddress(), new BT_Streaming(conn2));
				}
			}
		} catch (Exception e) {
			System.out.println("error man");
			e.printStackTrace();
			// TODO: handle exception
		}

	}

}
