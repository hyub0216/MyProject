// 0630 TG log ���� ��  

import java.io.IOException;

//Thin-Gateway;
public class ThinGateway {

	public static void main(String[] args) throws IOException {
		
		ThreadPool.getInstance().runWorker("BT_Listener", new BT_Manager());
		ThreadPool.getInstance().runWorker("SC_Listener", new SCListener());
	}
}


