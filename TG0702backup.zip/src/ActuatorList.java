import java.io.DataOutputStream;
import java.io.OutputStream;
import java.net.Socket;


public class ActuatorList {

	//temp class for test
	private static ActuatorList actuator;
	private ActuatorList()
	{
		Act_status = null;
	}
	private String Act_status;
	
	public static ActuatorList getInstance()
	{
		if(actuator==null)
			actuator = new ActuatorList();
		return actuator;
	}
	
	public void sendActMsg(String act_info)
	{
		String act_value =  act_info.split(",")[1];
		String server ="163.180.117.203";
		if(Act_status==null||!Act_status.equals(act_value))
		{
			try {
				Socket c = new Socket(server,0216);
				OutputStream os = c.getOutputStream();
				DataOutputStream dos = new DataOutputStream(os);
				dos.writeBytes(act_info);
				c.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			Act_status = act_value;
			//Actuator log , log type= 04
			MQTT.getInstance().publishLog("Actuator is "+act_value,
					"21");
		}
	}
}

