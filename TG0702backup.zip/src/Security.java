import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.json.simple.parser.ParseException;
import org.vertx.java.core.json.impl.Base64;


public class Security {
	
	private static String TG_ID ="TG01";
	private static Security security;
	private static int Secure_Key = 123456;
	private static int noun1, noun2;
	private static String SHA_key = null;
	protected static String IV = "AAAAAAAAAAAAAAAA";
	private static byte[] sendData;
	private static String topic = null;
	private static MQTT mqtt = null;
	public Security (){}
	
	public static Security getInstance()
	{
		if(security == null)
		{
			security = new Security();
		}
		return security;
	}
	
	public String idJSon(String data){
		StringBuilder sb = new StringBuilder();
		sb.append("{\"data\":\"");
		sb.append(data);
		sb.append("\",\"type\":\"03\"}");

		return sb.toString();
	}
	
	public String Padding(String data) {
		int paddingNum = data.length() % 16;
		paddingNum = 16 - paddingNum;
		StringBuilder sb = new StringBuilder();
		sb.append(data);
		for (int i = 0; i < paddingNum; i++) {
			sb.append(" ");
		}
		return sb.toString();
	}
	
	public byte[] bytePadding(byte[] data) {
		int num = 16 - data.length % 16;
		System.out.println("num : " + num);
		for (int i = 0; i < num; i++) {
			data[data.length] = '\0';
		}
		return data;
	}
	
	public void getTwoNouns() {
		noun1 = Secure_Key / 1000;
		noun2 = Secure_Key % 1000;
	}

	public void Generate_key() {
		SHA_key = SHA256(noun1, noun2);
	}

	public byte[] encrypt(String plainText, String encryptionKey)
			throws Exception {
		Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding", "SunJCE");
		SecretKeySpec key = new SecretKeySpec(encryptionKey.getBytes("UTF-8"),
				"AES");
		cipher.init(Cipher.ENCRYPT_MODE, key,
				new IvParameterSpec(IV.getBytes("UTF-8")));
		return cipher.doFinal(plainText.getBytes("UTF-8"));
	}

	public String decrypt(byte[] cipherText, String encryptionKey)
			throws Exception {
		Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding", "SunJCE");
		SecretKeySpec key = new SecretKeySpec(encryptionKey.getBytes("UTF-8"),
				"AES");
		cipher.init(Cipher.DECRYPT_MODE, key,
				new IvParameterSpec(IV.getBytes("UTF-8")));
		return new String(cipher.doFinal(cipherText), "UTF-8");
	}

	public String SHA256(int num1, int num2) {
		String SHA = "12345612431512315123154123";
		try {
			MessageDigest sh = MessageDigest.getInstance("SHA-256");
			String str = String.valueOf((num1 + 1) * (num1 - 1) * (num2 + 1)
					* (num2 - 1));
			sh.update(str.getBytes());
			byte byteData[] = sh.digest();
			StringBuffer sb = new StringBuffer();
			for (int i = 0; i < byteData.length; i++) {
				sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16)
						.substring(1));
			}
			SHA = sb.toString();

		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			SHA = null;
		}
		SHA = SHA.substring(0, 16);
		return SHA;
	}
	
	public int getNum1(String temp) {
		int num1;
		String test = temp.split(",")[0];
		num1 = Integer.parseInt(test.split(":")[1]);
		return num1;
	}

	public int getNum2(String temp) {
		int num2;
		String test = temp.split(":")[2];
		num2 = Integer.parseInt(test.split("}")[0]);
		return num2;
	}
	
	public void GetShaKeyFromSC(byte[] encrypted_msg)
	{
		System.out.println("making ShaKey....1");
		String tempData=null;
		getTwoNouns();
		System.out.println("making ShaKey....2");
		Generate_key();
		System.out.println("making ShaKey....3");
		try {
			tempData = decrypt(encrypted_msg, SHA_key);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("error- decrypt failed");
		}
		//������ secureŰ�� ���� ������ ������ ���� sha-key�� ��ȣȭ�� �Ѵ�.
		noun1 = getNum1(tempData);
		noun2 = getNum2(tempData);
		System.out.println("making ShaKey....4");
		System.out.println("noun1 : " + noun1 + ", noun2 : " + noun2);
		Generate_key();
		System.out.println("New Sha key : " + SHA_key);
		// SC�� ���� ���� ������ ���� sha-key ����
		
		try {
			sendData = encrypt(Padding(TG_ID), SHA_key);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		String sendData1 = Base64.encodeBytes(sendData);
		sendData1 = idJSon(sendData1);
		System.out.println("send data to Server: " + sendData1);
		MQTT.getInstance().SetKeyValue(TG_ID);
		mqtt = MQTT.getInstance();
		
		mqtt.publishConfig(sendData1);
		//�ڽ��� TG_ID�� ��ȣȭ �� SC�� ����
	}
	public String GetJsonMsg(byte[] encrypted_msg)
	{
		String decryptedData = null;
		try {
			System.out.println("decrypting....");
			decryptedData = decrypt(encrypted_msg, SHA_key);
			System.out.println("decryted msg : "+decryptedData);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("error- decrypt failed");
		}
		return decryptedData;
	}
	
	public void SetTopicFromJson(String msg)
	{
		MsgParser parser = new MsgParser();
		try {
			parser.SetMsg(msg);
		} catch (ParseException e) {
			System.out.println("error - parsing");
		}
		topic=parser.getTopic();
		
		System.out.println("setting ..... new topic : "+topic+" new secureKey : "+Secure_Key);
		
		mqtt.SetKeyValue(topic);
		mqtt.setGotTopic();
	}

	
	

}
