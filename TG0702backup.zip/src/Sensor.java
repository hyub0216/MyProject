import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 * @author This class can make Thin-Gateway translate JSON to String
 */
public class Sensor {

	private static HashMap<String, Object> SensorDatas = null;
	private static HashMap<String, Object> DefineEventTypeName = null;
	private static HashMap<String, Double> AverageSensorData = new HashMap<String, Double>();
	private static HashMap<String, Double> previousSensorData = new HashMap<String, Double>();
	private static JSONArray sensor_arry;
	private static int count = 0;

	public Sensor() {
		SensorDatas = new HashMap<String, Object>();
	}

	public void setSensor_arry(JSONArray sensorData) {
		sensor_arry = sensorData;
	}

	// Define EventType;
	public HashMap<String, Object> GetDefinedEventType() {
		DefineEventTypeName = new HashMap<String, Object>();
		// Check how many data include in that array
		Iterator<JSONObject> iter = sensor_arry.iterator();
		while (iter.hasNext()) {
			JSONObject obj = (JSONObject) iter.next();
			String SensorName = obj.toJSONString().split("\"")[1];
			;
			DefineEventTypeName.put(SensorName, Double.class);
		}
		return DefineEventTypeName;
	}

	// Check if it's a new EventType
	public boolean IsNewLackType() {
		if (DefineEventTypeName == null)
			return true;
		HashMap<String, Object> temp = new HashMap<String, Object>();
		// Check how many data include in that array
		Iterator<JSONObject> iter = sensor_arry.iterator();
		while (iter.hasNext()) {
			JSONObject obj = (JSONObject) iter.next();
			String SensorName = obj.toJSONString().split("\"")[1];
			temp.put(SensorName, Double.class);
		}
		if (temp.equals(DefineEventTypeName))
			return false;
		else
			return true;
	}

	// Get Average SensorData
	public void CalculateSensorDataAvg() {
		// Send AvgData to SC and initialize AverageSensorData Map, count
		Double SensorData;
		String SensorName;
		if (count == 10 ) {
			SaveAverage();
			SendDataToSC();
			AverageSensorData.clear();// Initialize HashMap
			count = 0;
			System.out.println("Send data to SC");
		}
		
		Iterator<JSONObject> iter = sensor_arry.iterator();
		// Insert SensorData into HashMap
		while (iter.hasNext()) {
			// obj has array of SensorDatas
			JSONObject obj = (JSONObject) iter.next();
			// Get Key
			SensorName = obj.toJSONString().split("\"")[1];

			// if it's new key
			if (AverageSensorData.isEmpty()
					|| !AverageSensorData.containsKey(SensorName)) {
				SensorData = (Double.parseDouble((String) obj.get(SensorName)));
				AverageSensorData.put(SensorName, SensorData / 10.0);
			} else if (AverageSensorData.containsKey(SensorName)) {
				Double temp = AverageSensorData.get(SensorName);
				SensorData = temp
						+ (Double.parseDouble((String) obj.get(SensorName)) / 10.0);
				AverageSensorData.replace(SensorName, temp, SensorData);
				// update value;
			}
		}
		count++;
	}
	
	public String NewRackLog()
	{
		HashMap<String, Object> temp = new HashMap<String, Object>();
		
		StringBuilder data = new StringBuilder();
		data.append("\"Rack_List\":[{\"Rack_ID\":\"Rack01\",\"Sensor_List\":[");
		Iterator<JSONObject> iter = sensor_arry.iterator();
		while (iter.hasNext()) {
			JSONObject obj = (JSONObject) iter.next();
			String SensorName = obj.toJSONString().split("\"")[1];
			data.append("\"");
			data.append(SensorName);
			if(iter.hasNext())
				data.append("\",");
			else
				data.append("\"");
		}
		data.append("]}]");
		
		data.append(",\"Act_List\":[{\"Act_ID\":\"Act03\",\"Status\":\"on\"},"
				+ "{\"Act_ID\":\"Act02\",\"Status\":\"on\"}]");
		System.out.println("++++++++++++++++++++++++++++++++++++++++++ LOG DATA ++++++++++++++++++++++++++++++++++++++++++");
		System.out.println(data.toString());
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		return data.toString();
	}

	// Send Average of SensorDatas to Smart-Cloud
	public void SendDataToSC() {
		// Convert HashMapData to Json
		
		StringBuilder data = new StringBuilder();
		data.append("{\"type\":\"sensordata\"");
		data.append(",\"tg_id\":\"");
		data.append(SCListener.getInstance().GetTG_ID());
		data.append("\",\"sensors_data\":[");
		Iterator<Entry<String, Double>> temp;
		temp = AverageSensorData.entrySet().iterator();

		// until there is no new SensorData info
		while (temp.hasNext()) {
			String Key = temp.next().getKey();
			data.append("{\"");
			data.append(Key);
			data.append("\":\"");
			data.append(AverageSensorData.get(Key));
			data.append("\"}");
			if (temp.hasNext())
				data.append(","); 
		}
		data.append("]}");
		if(MQTT.getInstance().GetKeyValue() != null)
			MQTT.getInstance().publishMsg(data.toString());
		System.out.println("Message : " + data.toString());
	}

	// Get SensorData in HashMap
	public HashMap<String, Object> GetSensorData() {
		Iterator<JSONObject> iter = sensor_arry.iterator();
		// Check how many data include in that array
		while (iter.hasNext()) {
			JSONObject obj = (JSONObject) iter.next();
			String SensorName = obj.toJSONString().split("\"")[1];
			Double SensorData = Double
					.parseDouble((String) obj.get(SensorName));
			SensorDatas.put(SensorName, SensorData);
		}
		return SensorDatas;
	}

	//Compare with avgData, if it is unusual data
	public void CompareWithAvg() {
		Iterator<JSONObject> iter = sensor_arry.iterator();
		if (!previousSensorData.isEmpty()) {
			while (iter.hasNext()) {
				JSONObject obj = (JSONObject) iter.next();
				String SensorName = obj.toJSONString().split("\"")[1];
				Double SensorData = Double.parseDouble((String) obj
						.get(SensorName));
				Double AvgSensorData = previousSensorData.get(SensorName);
				// Check if it is unusual data
				
				
				// 1.5 is temporary value , unusual alarm
				if (SensorData > (AvgSensorData * 1.2)
						|| SensorData < (AvgSensorData-(AvgSensorData*1.2))) {
					//log 
					MQTT.getInstance().publishLog(
							SensorName +(SensorData-AvgSensorData), "20");
				}
			}
		} else
			System.out.println("SensorAvgData doesn't exist");
	}

	public void SaveAverage() {
		previousSensorData.putAll(AverageSensorData);
	}
}
