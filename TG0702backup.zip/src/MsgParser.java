import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.vertx.java.core.json.impl.Base64;

/**
 * @author Parser for message from Smart-Cloud
 */
public class MsgParser {

	// JSON format
	private JSONObject Json_obj;
	private JSONParser parser;

	// Parser constructor
	public MsgParser() {
	}

	// Set Message
	public void SetMsg(String msg) throws ParseException {
		this.parser = new JSONParser();
		Object temp = parser.parse(msg);
		if (temp instanceof JSONObject) {
			Json_obj = (JSONObject) temp;
		} else
			System.out.println("Instance failed");
	}

	public byte[] getJsonBinary() {
		String temp = (String) Json_obj.get("data");

		return temp == null ? null : Base64.decode(temp);
	}
	public String getdataType()
	{
		return (String) Json_obj.get("type");
	}

	// Get SensorData formed JSONArray
	public JSONArray getSensorsData() {
		return (JSONArray) Json_obj.get("Sensors_data");

	}

	// Get LackID
	public String getLackID() {
		return (String) Json_obj.get("Lack_id");
	}

	public byte[] getDatatest() {
		return (byte[]) Json_obj.get("data");
	}

	// Get Event_num
	public String getEvent_num() throws ParseException {
		return (String) Json_obj.get("event_num");
	}

	// Get Push_type
	public String getPushType() throws ParseException {
		return (String) Json_obj.get("push_type");
	}

	// check if it's Actuator msg
	public boolean isActuator() throws ParseException {
		String type = (String) Json_obj.get("type");
		if (type.equals("actuator"))
			return true;
		else
			return false;
	}

	// Get EPL
	public String getEPL() {
		return (String) Json_obj.get("event");
	}

	// Get ListenerType
	public String getListenerType() {
		return (String) Json_obj.get("listenerType");
	}

	// Get Act_id
	public String getAct_id() {
		return (String) Json_obj.get("actuator_id");
	}

	public int getNum1() {
		System.out.println(Json_obj.get("num1"));
		return (Integer) Json_obj.get("num1");
	}

	public int getNum2() {
		return (Integer) Json_obj.get("num2");
	}

	// Get Act_value
	public String getAct_value() {
		return (String) Json_obj.get("action");
	}

	// Get Key_value
	public String getKey_value() {
		return (String) Json_obj.get("Key");
	}

	public boolean getNotice() {
		String temp = (String) Json_obj.get("notice");
		System.out.println(" data : " + temp);
		if (temp.isEmpty())
			return false;
		else
			return true;
	}

	public String getTopic() {
		return (String) Json_obj.get("topic");
	}

	public int getSecureNum() {
		String temp = (String) Json_obj.get("secureKey");
		return Integer.parseInt(temp);
	}

}
