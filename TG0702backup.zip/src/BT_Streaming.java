import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;

import javax.bluetooth.RemoteDevice;
import javax.microedition.io.StreamConnection;

/**
 * @author
 */
public class BT_Streaming implements Runnable {
	private  StreamConnection client;
	private  BufferedReader in;
	private  PrintStream out;
	private static Sensor m_Sensor = new Sensor();
	private static MsgParser msgParser = new MsgParser();

	// singleton : can use one instance anywhere

	public BT_Streaming(StreamConnection clnt) {
		client = clnt;
		try {
				in = new BufferedReader(new InputStreamReader(
						client.openInputStream()));
				out = new PrintStream(client.openOutputStream());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void run() {
		// get MQTT Instance
		RemoteDevice dev = null;
		try {
			dev = RemoteDevice.getRemoteDevice(client);
		} catch (IOException e2) {
			e2.printStackTrace();
			System.out.println("Error : " + e2.toString());
		}
		String SensorData = null;
		String LackAddr = dev.getBluetoothAddress();
		System.out.println("+++++ Addr : " + LackAddr + " Thread Start ++++++");
		// Add Event which is in DB to TG
		boolean AddDB = false;
		while (true) {
			try {
				System.out.println("+++++ Data Received ++++++");
				SensorData = in.readLine();
				System.out.println("Received: " + SensorData);
				if (isString(SensorData)) {
					try {
						// convert JSON Sensors_data to String and store
						// sensors_data
						msgParser.SetMsg(SensorData);
						m_Sensor.setSensor_arry(msgParser.getSensorsData());
						// Add new EventType
						if (m_Sensor.IsNewLackType()) {
							EventManager.getInstance().AddEventType(
									msgParser.getLackID(),
									m_Sensor.GetDefinedEventType());
							System.out.println("New Rack Data Defined");
							
							//log01 = new Rack added
							MQTT.getInstance().publishLog(
									m_Sensor.NewRackLog(), "Log01");
						}
						if (TG_DB.getInstance().hasEPL()&& !AddDB) {
							// Add Event in DB just one time
							TG_DB.getInstance().RegisterEvent();
							TG_DB.getInstance().CloseDB();
							AddDB = true;
						}
						EventManager.getInstance()
								.SendEvent(m_Sensor.GetSensorData(),
										msgParser.getLackID());
						// push Lack_data to SC
						m_Sensor.CalculateSensorDataAvg();// get Avg Data 10times
						m_Sensor.CompareWithAvg();
						
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
				System.out.println("Connection Error : " + e.toString());
			}
			if (SensorData == null)
			{
				System.out.println("No Sensor data");
				break;
			}
			out.println("got_msg");
		}
		try {
			client.close();
			System.out.println("+++++++++ Disconnected ++++++++");
			System.out.println("++++ Addr : " + LackAddr);
			ThreadPool.getInstance().stopWorkerFuture(LackAddr);
			
			// Log02 : Disconnected Rack
			MQTT.getInstance().publishLog("Disconnected Rack addr - " + LackAddr,
					"00");

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private boolean isString(String... params) {
		boolean bOk = true;
		for (String text : params) {
			if (text == null || text.length() <= 0) {
				bOk = false;
				break;
			}
		}
		return bOk;
	}

}