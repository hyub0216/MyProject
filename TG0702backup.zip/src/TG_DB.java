import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TG_DB {

	static TG_DB db_temp;
	static Connection conn = null;
	static Statement stmt;
	static ResultSet rs;
	static String sql = null;
	private static boolean hasEPL = false;
	public TG_DB() {
	}
//	singleton 
	public static TG_DB getInstance() {
		if (db_temp == null) {
			try {
				Class.forName("org.sqlite.JDBC");
				conn = DriverManager.getConnection("jdbc:sqlite:test.db");
				stmt = conn.createStatement();
				
//				Create EPL table in DB
				sql = "CREATE TABLE IF NOT EXISTS EPL"
						+ "(Event_num TEXT PRIMARY KEY NOT NULL,"
						+ "Event TEXT NOT NULL)";
				stmt.executeUpdate(sql);
						
//				Create Topic table in DB
				sql = "CREATE TABLE IF NOT EXISTS TOPIC" + "(Key_value TEXT NOT NULL)";
				stmt.executeUpdate(sql);
				db_temp = new TG_DB();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
				System.out.println("Error : " + e.toString());
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("Connection Error! " + e.toString());
			}
		}
		return db_temp;
	}
	public boolean hasEPL()
	{  
		try {
			rs = stmt.executeQuery("SELECT * FROM EPL;");
			hasEPL = rs.next();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return hasEPL;
	}

//	Store EPL in DB
	public void StoreEPL(String event_num, String event) {
		System.out.println("ADD epl : " + event_num);
		sql = "INSERT INTO EPL (Event_num,Event) "
				+ "VALUES ('"+event_num+"','"+event+"');";
		try {
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			System.out.println("EPL update failed" );
			e.printStackTrace();
		}
		PrintEPL();

	}
//	Store TopicKeyValue in DB
	public void StoreKeyValue(String key)
	{
		sql = "INSERT INTO TOPIC (Key_value) "
				+ "VALUES ('"+key+"');";
		try {
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			System.out.println("Insert Key Value failed : "+e.toString());
		}
	}
	public void PrintEPL()
	{
		try {
			rs = stmt.executeQuery("SELECT * FROM EPL;");
			while(rs.next())
			{
				System.out.println("Event_num : " +rs.getString("Event_num"));
				String epl = rs.getString("Event");
				System.out.println("Event : " +epl);
				System.out.println("EPL JSON : "+epl);
			}
		} catch (SQLException e) {
			System.out.println("No Event in DB");
		}
	}
	
	
//	Register EPL for EventManager
	public void RegisterEvent()
	{
		try {
			rs = stmt.executeQuery("SELECT * FROM EPL;");
			while(rs.next())
			{
				System.out.println("Event_num : " +rs.getString("Event_num"));
				String epl = rs.getString("Event");
				System.out.println("Event : " +epl);
				SCListener.getInstance().inputEvent(epl,true);
				MQTT.getInstance().publishLog("New_event("+epl+")is added", "11");
			}
		} catch (SQLException e) {
			System.out.println("No Event in DB");
		}
	}
	
//	return TopicKeyValue
	public String GetKeyValue()
	{
		try {
			rs = stmt.executeQuery("SELECT Key_value FROM TOPIC");
			return rs.getString("Key_value");
		} catch (SQLException e) {
			System.out.println("Doesn't have Key_value");
			return null;
		}
	}
	
//	Remove selected EPL in DB
	public void RemoveEvent(String event_num)
	{
		sql = "DELETE FROM EPL"
				+"WHERE Event_num ='"+event_num+"'";
	}
	
//	close DB
	public void CloseDB()
	{
		try {
			db_temp =null;
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Close failed" +e.toString());
		}
	}

}
