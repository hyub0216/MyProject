var mongoose = require('mongoose');

module.exports = function(connection) {

    var Schema = mongoose.Schema;

    var memberSchema = new Schema({
        name: String,
        nameEng: String,
        course: String,
        research: String,
        email: String,
        graduate: Number,
        picture: Number
    });

    var Member = connection.model('Member', memberSchema);

    return Member;
}