var mongoose = require('mongoose');

module.exports = function(connection) {

    var Schema = mongoose.Schema;

    var techTransSchema = new Schema({
        patentIdx: String,
        title: String,
        year: String,
        country: String,
        preFee: String,
        crtFee: String,
        contract: String,
        deposit: String,
        type: String,
        organ: String,
        num: String,
        gFund: String,
        cFund: String,
        file: String
    });

    var TechTrans = connection.model('TechTrans', techTransSchema, 'patents');

    return TechTrans;
};