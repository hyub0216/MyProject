var mongoose = require('mongoose');

module.exports = function(connection) {

    var Schema = mongoose.Schema;

    var writingSchema = new Schema({
        id: String,
        type: String,
        regdate: String,
        name: String,
        writer: String,
        title: String,
        content: String,
        uploaded: [String],
        d_count: Number,
        hit: Number
    });

    var Writing = connection.model('Writing', writingSchema, 'lecture');

    return Writing;
}