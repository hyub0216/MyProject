var mongoose = require('mongoose');
var moment = require('moment');
var expired_time = 60;

module.exports = function(connection) {

    var Schema = mongoose.Schema;

    var userSchema = new Schema({
        email: String,
        name: String,
        password: String,
        scope: String,
        token : {
            auth_token: String,
            createDate: {type: Date, required: true, default: moment()}
        }
    });

    userSchema.methods.hasExpired = function() {
        return (moment().diff(this.token.createDate, 'minutes')) > expired_time;

    };

    var User = connection.model('User', userSchema);

    return User;
}