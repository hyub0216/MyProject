var mongoose = require('mongoose');

module.exports = function(connection) {

    var Schema = mongoose.Schema;

    var profPositionSchema = new Schema({
        start: String,
        end: String,
        organization: String,
        position: String
    });

    var ProfPosition = connection.model('ProfPosition', profPositionSchema);

    return ProfPosition;
}