var mongoose = require('mongoose');

module.exports = function(connection) {

    var Schema = mongoose.Schema;

    var lectureSchema = new Schema({
        id: String,
        year: String,
        semester: String,
        type: String,
        title: String
    });

    var Lecture = connection.model('Lecture', lectureSchema, 'lecture');

    return Lecture;
}