var mongoose = require('mongoose');

module.exports = function(connection) {

    var Schema = mongoose.Schema;

    var patentSchema = new Schema({
        year: String,
        country: String,
        type: String,
        num: String,
        title: String,
        organ: [String],
        organNum: String,
        pubDate: String,
        openState: String,
        ack: String,
        inventor: [String],
        status: String,
        file: String,
        bTrans: Boolean
    });

    var Patent = connection.model('Patent', patentSchema);

    return Patent;
}