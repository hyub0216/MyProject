module.exports = function(connection) {

    var User = require('./user')(connection);
    var Member = require('./member')(connection);
    var ProfPosition = require('./prof_position')(connection);
    var Project = require('./project')(connection);
    var Lecture = require('./lecture')(connection);
    var Writing = require('./writing')(connection);
    var Paper = require('./paper')(connection);
    var Nation = require('./nation')(connection);
    var Patent = require('./patent')(connection);
    var TechTrans = require('./tech_trans')(connection);

    return {
        user: User,
        member: Member,
        profPosition: ProfPosition,
        project: Project,
        lecture: Lecture,
        writing: Writing,
        paper: Paper,
        nation: Nation,
        techTrans: TechTrans,
        patent: Patent
    };
};