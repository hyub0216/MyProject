var mongoose = require('mongoose');

module.exports = function(connection) {

    var Schema = mongoose.Schema;

    var paperSchema = new Schema({
        jTitle: String,
        cTitle: String,
        nation: String,
        status: String,
        issn: String,
        iFactor: String,
        pStart: String,
        pEnd: String,
        pTitle: String,
        author: String,
        coAuthor: [String],
        published: String,
        preDate: String,
        vol: String,
        no: String,
        year: String,
        type: String,
        ack: [String],
        pFile: String
    });

    var Paper = connection.model('Paper', paperSchema);

    return Paper;
}