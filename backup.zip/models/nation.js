var mongoose = require('mongoose');

module.exports = function(connection) {

    var Schema = mongoose.Schema;

    var nationSchema = new Schema({
        nation: String,
        code: String
    });

    var Nation = connection.model('Nation', nationSchema);

    return Nation;
}