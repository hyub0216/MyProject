var mongoose = require('mongoose');

module.exports = function(connection) {

    var Schema = mongoose.Schema;

    var projectSchema = new Schema({
        idx: Number,
        start: String,
        end: String,
        title: String,
        organ: String,
        total_fund: String,
        assign_fund: String,
        ack: String,
        ack_ko: String,
        ack_eng: String
    });

    var Project = connection.model('Project', projectSchema);

    return Project;
}