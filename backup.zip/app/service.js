define(['angular'], function (angular) {
    'use strict';

    var myAppServices = angular.module('myAppServices', []);

    myAppServices.service('TokenInterceptor', ['$q', '$location', 'localStorageService',
        function ($q, $location, localStorageService)
        {
            return {
                request: function (config) {
                    config.headers = config.headers || {};

                    if (localStorageService.get("auth_token") !== null)
                        config.headers.Authorization = 'Bearer ' + localStorageService.get("auth_token");
                    return config;
                },
                response: function (response) {
                    return response || $q.when(response);
                },
                responseError: function (response) {
                    if (response.config.url !== "/api/login" && response.status === 401) {
                        localStorageService.clearAll();
                        $location.path("/home");

                        new PNotify({
                            title: 'Error !!',
                            text: 'Some errors occured...',
                            type: 'error'
                        });
                    }

                    return $q.reject(response);

                }
            };
        }]);

    myAppServices.service('cryptoJSService',
            function () {
                return CryptoJS;
            });

    myAppServices.service('AuthenticationService', ['localStorageService', function (localStorageService) {
            return {
                isLogged: function ()
                {
                    var authenticated = false;
                    if (localStorageService.get("auth_token") !== null)
                        authenticated = true;

                    return authenticated;
                },
                isMember: function ()
                {
                    var authenticated = false;
                    if (localStorageService.get("scope") === "member" || localStorageService.get("scope") === "admin")
                        authenticated = true;

                    return authenticated;
                },
                isAssistant: function ()
                {
                    var authenticated = false;
                    if (localStorageService.get("scope") === "assist")
                        authenticated = true;

                    return authenticated;
                }
            };
        }]);

    myAppServices.service('fileListService', [function () {
            return {
                getHtml: function (item) {
                    var files = '';
                    $.each(item.uploaded, function (i, element) {
                        var data = JSON.parse(element);
                        files += '<a href="" style="margin-left: 10px;"><i class="fa fa-paperclip" onClick=\'onDownload(' + i + ')\'>' + data.filename + '</i></a>'
                    });
                    return files;
                }
            };
        }]);

    return myAppServices;
});

