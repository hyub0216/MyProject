define(['angular'], function (angular) {
    'use strict';

    var myAppFilters = angular.module('myAppFilters', []);

//    myAppFilters.filter("asDate", ['$filter', function ($filter) {
//
//            return function (input) {
//                var input_day = new Date(input.replace(/-/g, '/'));
//                var check_day = $filter('date')(input_day, 'yyyyMMdd');
//                if (angular.equals(check_day, $filter('date')(new Date, 'yyyyMMdd'))) {
//
//                    return $filter('date')(input_day, 'HH:mm:ss').toString();
//                } else {
//                    return $filter('date')(input_day, 'yy/MM/dd').toString();
//                }
//            }
//        }]);
//
//    myAppFilters.filter("strLength", ['$filter', function ($filter) {
//
//            return function (input) {
//                var input_day = new Date(input.replace(/-/g, '/'));
//                var check_day = $filter('date')(input_day, 'yyyyMMdd');
//                if (angular.equals(check_day, $filter('date')(new Date, 'yyyyMMdd'))) {
//                    return $filter('date')(input_day, 'HH:mm:ss').toString();
//                } else {
//                    return $filter('date')(input_day, 'yy/MM/dd').toString();
//                }
//            }
//        }]);

    myAppFilters.filter("asDateformat", ['$filter', function ($filter) {

            return function (input) {
                var year = input.substring(0, 4);
                var month = input.substring(4, 6);
                var day = input.substring(6, 8);

                return year + '.' + month + '.' + day;
            };
        }]);

    myAppFilters.filter("startWith", function () {
        return function (input, cur) {
            if (input !== undefined) {
                var output = new Array();
                angular.forEach(input, function (paper) {
                    if (paper.type === cur) {
                        output.push(paper);
                    };
                });
                return output;
            }
        };
    });


    return myAppFilters;
});