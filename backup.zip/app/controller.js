define(['angular'], function (angular) {//"angular", 'fancybox', 'slides', 'mixitup', 'movetop', 'easing', 'picasa'
    'use strict';
    var mainAppControllers = angular.module('mainAppControllers', ['textAngular'
//        'fancybox', 
//        'slides', 
//        'mixitup', 
//        'movetop', 
//        'easing', 
//        'picasa'
    ]);



    mainAppControllers.controller('NavCtrl', ['$scope', '$http', '$location', 'localStorageService', 'cryptoJSService', 'AuthenticationService',
        function ($scope, $http, $location, localStorageService, CryptoJS, AuthenticationService) {
            PNotify.prototype.options.delay = 1800;
            PNotify.prototype.options.animate_speed = 200;

            $scope.isHome = function () {
                return $location.path() === '/home';
            };

            $("span.menu").click(function () {
                $(".top-nav ul").slideToggle(500, function () {
                });
            });
            $('#login').click(function (e) {
                $('#login-page').lightbox_me({
                    centered: true,
                    onLoad: function () {
                        $('#login-page').find('input:first').focus();
                    },
                    onClose: function () {
                        $scope.refresh();
                        if (!localStorageService.get("clicked")) {
                            $scope.$apply();
                        }
                    }
                });
                e.preventDefault();
            });

            $scope.setState = function (state) {
                $scope.loginstate = state;
            };

            $scope.refresh = function () {
                $('input').val('');
                $scope.setState(1);
                $scope.id = '';
                $scope.pass = '';
                $scope.email = '';
                $scope.isLogged = AuthenticationService.isLogged();
                $scope.isAuthenticated = $scope.isLogged && AuthenticationService.isMember();
                $scope.username = localStorageService.get("username") || "Guest";
            };
            $scope.refresh();

            $scope.logout = function () {
                localStorageService.clearAll();
                $location.path("/home");
                $scope.refresh();
            };
            $scope.submit = function (id, pass) {
                localStorageService.set("clicked", true);
                $('#login-page').trigger('close');

                if (id === undefined || pass === undefined || id === '' || pass === '') {
                    console.log('empty');
                    new PNotify({
                        title: 'Sign in failed',
                        text: 'Please give me your ID and PW',
                        type: 'warning'
                    });
                } else {
                    var enc_password = CryptoJS.PBKDF2(pass, id, {keySize: 256 / 32});

                    $http.post("/api/login", {email: id, pass: enc_password.toString()}).
                            success(function (data, status, headers, config) {//    xjuszyxi1bp4
                                localStorageService.set("username", data.name);
                                localStorageService.set("auth_token", data.auth_token);
                                localStorageService.set("scope", data.scope);
                                $scope.refresh();
                                new PNotify({
                                    title: 'Welcome to ICNS Lab.',
                                    text: data.name + ' 님의 방문을 환영합니다.',
                                    type: 'success'
                                });
                            }).
                            error(function (data, status, headers, config) {
                                new PNotify({
                                    title: status + ' Error !!!',
                                    text: 'Wrong username and/or password!',
                                    type: 'error'
                                });
                                if (status === 401) {
                                    console.log('Wrong username and/or password!');
                                } else {
                                    console.log('error');
                                }
                            });
                }
            };
            $scope.sendEmail = function (email) {
                localStorageService.set("clicked", true);
                $('#login-page').trigger('close');

                var password = Math.random().toString(36).substr(2, 12);
                var enc_password = CryptoJS.PBKDF2(password, email, {keySize: 256 / 32});
                $http.post('/api/sendEmail', {email: email, password: password, enc_password: enc_password.toString()}).
                        success(function (data) {
                            console.log(data);
                        }).
                        error(function (data, status, headers, config) {
                            if (status !== 401) {
                                console.log("error - " + status);
                            }
                        });
            };
        }
    ]);
    mainAppControllers.controller('HomeCtrl', ['$scope', '$http', '$filter',
        function ($scope, $http, $filter) {

            var $filterlist = $('#filterlist');
            var mix = {
                init: function () {
                    $filterlist.mixItUp({
                        load: {
                            sort: 'date:desc'
                        },
                        sort: 'date:desc',
                        effects: ['fade'],
                        easing: 'snap'
                    });
                    $filterlist.mixItUp('multiMix', {sort: 'date:desc'});
                }
            };
            $("#slider1").responsiveSlides({
                auto: true,
                nav: false,
                speed: 600,
                namespace: "callbacks",
                pager: false
            });
            $.picasa.recentAlbumImages(2, 8, ['6137163571545195697', '6130419378461696129', '6137162430948526017', '6130413274827402993'], $filter, function (images) {
                $filterlist.append(images);
            }, function () {
                $("a.grouped_elements").fancybox({
                    padding: 0,
                    helpers: {
                        title: {
                            type: 'over'
                        }
                    }
                });
                mix.init();
            });
            if (!$filterlist.mixItUp('isLoaded')) {
                mix.init();
            } else {
                $filterlist.mixItUp('destroy');
                mix.init();
            }

        }
    ]);
    mainAppControllers.controller('Home2Ctrl', ['$scope', '$http', '$filter',
        function ($scope, $http, $filter) {

            var $filterlist = $('#filterlist');
            var mix = {
                init: function () {
                    $filterlist.mixItUp({
                        load: {
                            sort: 'date:desc'
                        },
                        sort: 'date:desc',
                        effects: ['fade'],
                        easing: 'snap'
                    });
                    $filterlist.mixItUp('multiMix', {sort: 'date:desc'});
                }
            };
            $("#slider1").responsiveSlides({
                auto: true,
                nav: false,
                speed: 500,
                namespace: "callbacks",
                pager: false
            });
            $.picasa.tempImages(2, $filter, function (images) {
                $("a.grouped_elements").fancybox({
                    helpers: {
                        title: {
                            type: 'over',
                            centerOnScroll: true
                        }
                    },
                    centerOnScroll: true,
                    onComplete: function () {
                        $.fancybox.center();
                    }
                });
                $filterlist.append(images);
                mix.init();
            });
            if (!$filterlist.mixItUp('isLoaded')) {
                mix.init();
            } else {
                $filterlist.mixItUp('destroy');
                mix.init();
            }

        }
    ]);
    mainAppControllers.controller('ProfCtrl', ['$scope', '$http',
        function ($scope, $http) {
            $http.get('/api/positions').
                    success(function (data) {
                        $.each(data.positions, function (i, element) {
                            if (element.end === "") {
                                element.end = "현 재";
                            } else {
                                element.end += "년";
                            }
                        });
                        $scope.positions = data.positions;
                    }).
                    error(function (data, status, headers, config) {
                        if (status !== 401) {
                            console.log("error - " + status);
                        }
                    });
        }
    ]);
    mainAppControllers.controller('MemberCtrl', ['$scope', '$http',
        function ($scope, $http) {
            var $filterlist = $('#filterlist');
            var mix = {
                init: function () {
                    $filterlist.mixItUp({
                        load: {
                            sort: 'grad:desc align:desc num:asc'
                        },
                        sort: 'grad:desc align:desc num:asc',
                        effects: ['fade'],
                        easing: 'snap'
                    });
                    $filterlist.mixItUp('multiMix', {sort: 'grad:desc align:desc num:asc'});
                }
            };
            $http.get('/api/members').
                    success(function (data, status, headers, config) {
                        $.picasa.memberImages(data.members, 2, function (images) {
                            $("a.grouped_elements").fancybox({
                                helpers: {
                                    title: {
                                        type: 'over'
                                    }
                                }
                            });
                            $filterlist.append(images);
                            mix.init();
                        });
                    }).
                    error(function (data, status, headers, config) {
                        if (status !== 401) {
                            console.log("error - " + status);
                        }
                    });
            if (!$filterlist.mixItUp('isLoaded')) {
                mix.init();
            } else {
                $filterlist.mixItUp('destroy');
                mix.init();
            }
        }
    ]);
    mainAppControllers.controller('ProjectCtrl', ['$scope', '$http',
        function ($scope, $http) {
            $http.get('/api/projectlist').
                    success(function (data) {
                        $scope.projectlist = data.projectlist;
                    }).
                    error(function (data, status, headers, config) {
                        if (status !== 401) {
                            console.log("error - " + status);
                        }
                    });
        }
    ]);
    mainAppControllers.controller('PublicationCtrl', ['$scope', '$http', 'AuthenticationService',
        function ($scope, $http, AuthenticationService) {
            $scope.selectedYear = '';
            $scope.selectedType = 'All';

            $scope.isLogged = AuthenticationService.isLogged();
            $scope.isAuthenticated = $scope.isLogged && AuthenticationService.isMember();

            $http.get('/api/paperYearList').
                    success(function (data) {
                        $scope.yearlist = data.yearlist;
                        $scope.selectedYear = $scope.yearlist[0]._id;
                    }).
                    error(function (data, status, headers, config) {
                        if (status !== 401) {
                            console.log("error - " + status);
                        }
                    });
            $http.get('/api/paperlist').
                    success(function (data) {
                        $scope.paperlist = data.paperlist;
                    }).
                    error(function (data, status, headers, config) {
                        if (status !== 401) {
                            console.log("error - " + status);
                        }
                    });

            $scope.onYearSelected = function (year) {
                $scope.selectedYear = year;
            };
            $scope.checkYear = function (year) {
                return ($scope.selectedYear === year);
            };
            $scope.setType = function (type) {
                $scope.selectedType = type;
            };
            $scope.checkType = function (type) {
                return (($scope.selectedType === 'All') || (type.startsWith($scope.selectedType)));
            };
        }
    ]);
    mainAppControllers.controller('PatentCtrl', ['$scope', '$http', 'AuthenticationService',
        function ($scope, $http, AuthenticationService) {
            $scope.selectedYear = '';

            $scope.isLogged = AuthenticationService.isLogged();
            $scope.isAuthenticated = $scope.isLogged && AuthenticationService.isMember();

            $http.get('/api/patentYearList').
                    success(function (data) {
                        $scope.yearlist = data.yearlist;
                        $scope.selectedYear = $scope.yearlist[0]._id;
                    }).
                    error(function (data, status, headers, config) {
                        if (status !== 401) {
                            console.log("error - " + status);
                        }
                    });
            $http.get('/api/patentlist').
                    success(function (data) {
                        $scope.patentlist = data.patentlist;
                    }).
                    error(function (data, status, headers, config) {
                        if (status !== 401) {
                            console.log("error - " + status);
                        }
                    });
            $http.get('/api/translist').
                    success(function (data) {
                        $scope.translist = data.translist;
                    }).
                    error(function (data, status, headers, config) {
                        if (status !== 401) {
                            console.log("error - " + status);
                        }
                    });

            $scope.onYearSelected = function (year) {
                $scope.selectedYear = year;
            };
            $scope.checkYear = function (year) {
                console.log($scope.selectedYear === year);
                return ($scope.selectedYear === year);
            };
        }
    ]);
    mainAppControllers.controller('LectureCtrl', ['$scope', '$http', 'AuthenticationService', 'fileListService',
        function ($scope, $http, AuthenticationService, fileListService) {

            $scope.isLogged = AuthenticationService.isLogged();
            $scope.isAuthenticated = true;//$scope.isLogged && AuthenticationService.isMember();

            $scope.isEdit = false;
            var curItem = null;
            $scope.filelist = '';
            $scope.isShow = false;
            var selectedLecture = '';
            $scope.type = 'lecture';
            $scope.writingData = '';
            $scope.writinglist = '';
            $scope.writing_count = 15;
            $scope.writing_page = 1;
            $scope.writing_total = 0;
            $scope.getWritinglist = function () {
                $http.post('/api/lectureWritinglist', {id: selectedLecture.id, type: $scope.type}).
                        success(function (data) {
                            $scope.writingData = data.writinglist;
                            $scope.writing_total = $scope.writingData.length;
                            $scope.writinglist = $scope.writingData.slice(0, $scope.writing_count);
                            $scope.writing_page = 1;
                        }).
                        error(function (data, status, headers, config) {
                            if (status !== 401) {
                                console.log("error - " + status);
                            }
                        });
            };
            var filterData = function () {
                $scope.writinglist = $scope.writingData.slice(($scope.writing_page - 1) * $scope.writing_count, $scope.writing_page * $scope.writing_count);
            };
            $scope.onLectureSelected = function (lecture) {
                if (lecture === 0) {
                    if (selectedLecture === '') {
                        return false;
                    }
                } else {
                    selectedLecture = lecture;
                    $scope.getWritinglist();
                }
                return true;
            };
            $scope.getlecturelist = function (data) {
                $http.post('/api/lecturelist', data).
                        success(function (data) {
                            $scope.lecturelist = data.lecturelist;
                            $scope.onLectureSelected($scope.lecturelist[0]);
                        }).
                        error(function (data, status, headers, config) {
                            if (status !== 401) {
                                console.log("error - " + status);
                            }
                        });
            };
            $http.get('/api/yearlist').
                    success(function (data) {
                        $scope.yearlist = data.yearlist;
                        $scope.getlecturelist({year: $scope.yearlist[0]._id, semester: $scope.yearlist[0].semesters[0]});
                    }).
                    error(function (data, status, headers, config) {
                        if (status !== 401) {
                            console.log("error - " + status);
                        }
                    });

            $scope.setType = function (type) {
                $scope.type = type;
                $scope.getWritinglist();
            };
            $scope.onNextClicked = function () {
                $scope.writing_page++;
                filterData();
            };
            $scope.onPrevClicked = function () {
                $scope.writing_page--;
                filterData();
            };
            $scope.clicked = function (item) {
                if ($scope.isAuthenticated || $scope.type === 'lecture') {
                    if (item !== undefined) {
                        curItem = item;
                        $scope.filelist = JSON.parse(curItem.uploaded);
                        $scope.EditorTitle = item.title;
                        $scope.EditorContent = item.content;
                    }
                    $scope.isShow = true;
                    $('#editorCover').lightbox_me({
                        centered: true,
                        onClose: function () {
                            $scope.isShow = false;
                            $scope.EditorContent = '';
                            $scope.EditorTitle = '';
                            $scope.isEdit = false;
                            $('.editorTitle').attr('disabled', !$scope.isEdit);
                            $('#editorFiles').empty();
                            item = null;
                        }
                    });
                }
            };
            $scope.onEdit = function () {
                $scope.isEdit = true;
                $('.editorTitle').attr('disabled', !$scope.isEdit);
                $('.editorTitle').focus();
            };
            $scope.onCancel = function () {
                $('#editorCover').trigger('close');
            };
            $scope.onDownload = function (file) {
                console.log('file type : ' + typeof file)
                if (file !== undefined) {
                    if (typeof file === 'blob') {
                        download(file, curItem.title);
                    } else {
                        var x = new XMLHttpRequest();
                        x.open("GET", file.path, true);
                        x.responseType = 'blob';
                        x.onload = function (e) {
                            download(x.response, file.filename);
                        };
                        x.send();
                    }
                }
                ;
            };

            $scope.onListDownload = function (filelist) {
                var list = JSON.parse(filelist);
                console.log(list);

                if (list !== undefined) {
                    if (list.length > 1) {
                        console.log(list.length);
                        zip.workerScriptsPath = './js/zip/';
                        zip.createWriter(new zip.BlobWriter(), function (writer) {
                            console.log('writing');
                            $.each(list, function (i, element) {
                                var fileURL = element.path;
                                var fileName = element.filename;
                                console.log(fileName);

                                var request = $.ajax({
                                    url: fileURL,
                                    type: "GET",
                                    mimeType: 'text/plain; charset=x-user-defined'
                                });
                                request.done(function (data) {
                                    writer.add(fileName, new zip.BlobWriter(data), function(){console.log('success');});
                                });
                            });
                            writer.close(function (blob) {
                                download(blob);
                            });
                        }, function (error) {
                            console.log(error);
                        });
                    } else {
                        $scope.onDownload(list[0]);
                    }
                }
            };
        }
    ]);

    mainAppControllers.controller('FootCtrl', ['$scope', '$http', '$rootScope', '$location',
        function ($scope, $http, $rootScope, $location) {
            $scope.animate = function () {
                $("html, body").animate({scrollTop: 0}, "slow");
            };
        }
    ]);



    return mainAppControllers;
});