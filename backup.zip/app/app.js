define([
    'angular',
    'angularRoute',
    'angularLocalStorage',
    'controller',
    'directive',
    'service',
    'filter'
], function (angular) {
    'use strict';

    var mainApp = angular.module('mainApp', [
        'LocalStorageModule',
        'mainAppControllers',
        'ngRoute',
        'myAppFilters',
        'myAppServices',
        'myApp.directives'
    ]);

    mainApp.config(['$httpProvider', function ($httpProvider) {
            $httpProvider.interceptors.push('TokenInterceptor');
        }]);

    mainApp.config(['$routeProvider',
        function ($routeProvider) {

            $routeProvider.
                    when('/home', {
                        templateUrl: 'home',
                        controller: 'HomeCtrl',
                        access: {requiredLogin: false}
                    }).
                    // temp!!!!!!!!!!!
                    when('/home2', {
                        templateUrl: 'home2',
                        controller: 'Home2Ctrl',
                        access: {requiredLogin: false}
                    }).
                    when('/introduction', {
                        templateUrl: 'introduction',
                        access: {requiredLogin: false}
                    }).
                    when('/professor', {
                        templateUrl: 'introduction_professor',
                        controller: 'ProfCtrl',
                        access: {requiredLogin: false}
                    }).
                    when('/members', {
                        templateUrl: 'introduction_members',
                        controller: 'MemberCtrl',
                        access: {requiredLogin: false}
                    }).
                    when('/location', {
                        templateUrl: 'introduction_location',
                        controller: 'MemberCtrl',
                        access: {requiredLogin: false}
                    }).
                    // temp!!!!!!!!!!!
                    when('/introduction2', {
                        templateUrl: 'introduction2',
                        access: {requiredLogin: false}
                    }).
                    when('/professor2', {
                        templateUrl: 'introduction_professor2',
                        controller: 'ProfCtrl',
                        access: {requiredLogin: false}
                    }).
                    when('/members2', {
                        templateUrl: 'introduction_members2',
                        controller: 'MemberCtrl',
                        access: {requiredLogin: false}
                    }).
                    when('/location2', {
                        templateUrl: 'introduction_location2',
                        controller: 'MemberCtrl',
                        access: {requiredLogin: false}
                    }).
                    when('/project', {
                        templateUrl: 'project',
                        controller: 'ProjectCtrl',
                        access: {requiredLogin: false}
                    }).
                    when('/publication', {
                        templateUrl: 'publication',
                        controller: 'PublicationCtrl',
                        access: {requiredLogin: false}
                    }).
                    when('/publication_patent', {
                        templateUrl: 'publication_patent',
                        controller: 'PatentCtrl',
                        access: {requiredLogin: false}
                    }).
                    when('/publication_ltis', {
                        templateUrl: '404',
                        access: {requiredLogin: false}
                    }).
                    when('/publication_ltis2', {
                        templateUrl: 'publication_ltis',
                        access: {requiredLogin: false}
                    }).
                    when('/research', {
                        templateUrl: 'research',
                        controller: 'HomeCtrl',
                        access: {requiredLogin: false}
                    }).
                    when('/lecture', {
                        templateUrl: 'lecture',
                        controller: 'LectureCtrl',
                        access: {requiredLogin: false}
                    }).
                    when('/activity', {
                        templateUrl: 'activity',
                        controller: 'HomeCtrl',
                        access: {requiredLogin: false}
                    }).
                    otherwise({
                        redirectTo: '/home'
                    });
        }
    ]);

    mainApp.run(['$rootScope', '$location', 'AuthenticationService', function ($rootScope, $location, AuthenticationService) {
            $rootScope.$on("$routeChangeStart", function (event, nextRoute, currentRoute) {

//            if (nextRoute.access.requiredLogin && !AuthenticationService.isLogged()) {
//                $location.path("/login");
//            }
            });
        }]);

    return mainApp;
});