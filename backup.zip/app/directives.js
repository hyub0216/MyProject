'use strict';

/* Directives */
var myAppDirectives = angular.module('myApp.directives', []);

myAppDirectives.directive('appVersion', ['version', function (version) {
        return function (scope, elm, attrs) {
            elm.text(version);
        };
    }]);

myAppDirectives.directive('compileData', function ($compile) {
    return {
        scope: true,
        link: function (scope, element, attrs) {
            var elmnt;
            attrs.$observe('template', function (myTemplate) {
                if (angular.isDefined(myTemplate)) {
                    // compile the provided template against the current scope
                    elmnt = $compile(myTemplate)(scope);
                    element.html(""); // dummy "clear"
                    element.append(elmnt);
                }
            });
        }
    };
});

//myAppDirectives.directive('pdfDownload', function() {
//return {
//    restrict: 'E',
//    templateUrl: '/path/to/pdfDownload.tpl.html',
//    scope: true,
//    link: function(scope, element, attr) {
//        var anchor = element.children()[0];
//
//        // When the download starts, disable the link
//        scope.$on('download-start', function() {
//            $(anchor).attr('disabled', 'disabled');
//        });
//
//        // When the download finishes, attach the data to the link. Enable the link and change its appearance.
//        scope.$on('downloaded', function(event, data) {
//            $(anchor).attr({
//                href: 'data:application/pdf;base64,' + data,
//                download: attr.filename
//            })
//                .removeAttr('disabled')
//                .text('Save')
//                .removeClass('btn-primary')
//                .addClass('btn-success');
//
//            // Also overwrite the download pdf function to do nothing.
//            scope.downloadPdf = function() {
//            };
//        });
//    },
//    controller: ['$scope', '$attrs', '$http', function($scope, $attrs, $http) {
//        $scope.downloadPdf = function() {
//            $scope.$emit('download-start');
//            $http.get($attrs.url).then(function(response) {
//                $scope.$emit('downloaded', response.data);
//            });
//        };
//    }] 
//}});

//myAppDirectives.directive('ngContextMenu', function ($parse) {
//    var renderContextMenu = function ($scope, event, options) {
//        if (!$) { var $ = angular.element; }
//        $(event.currentTarget).addClass('context');
//        var $contextMenu = $('<div>');
//        $contextMenu.addClass('dropdown clearfix');
//        var $ul = $('<ul>');
//        $ul.addClass('dropdown-menu');
//        $ul.attr({ 'role': 'menu' });
//        $ul.css({
//            display: 'block',
//            position: 'absolute',
//            left: event.pageX + 'px',
//            top: event.pageY + 'px'
//        });
//        angular.forEach(options, function (item, i) {
//            var $li = $('<li>');
//            if (item === null) {
//                $li.addClass('divider');
//            } else {
//                $a = $('<a>');
//                $a.attr({ tabindex: '-1', href: '#' });
//                $a.text(item[0]);
//                $li.append($a);
//                $li.on('click', function () {
//                    $scope.$apply(function() {
//                        item[1].call($scope, $scope);
//                    });
//                });
//            }
//            $ul.append($li);
//        });
//        $contextMenu.append($ul);
//        $contextMenu.css({
//            width: '100%',
//            height: '100%',
//            position: 'absolute',
//            top: 0,
//            left: 0,
//            zIndex: 9999
//        });
//        $(document).find('body').append($contextMenu);
//        $contextMenu.on("click", function (e) {
//            $(event.currentTarget).removeClass('context');
//            $contextMenu.remove();
//        }).on('contextmenu', function (event) {
//            $(event.currentTarget).removeClass('context');
//            event.preventDefault();
//            $contextMenu.remove();
//        });
//    };
//    return function ($scope, element, attrs) {
//        element.on('contextmenu', function (event) {
//            $scope.$apply(function () {
//                event.preventDefault();
//                var options = $scope.$eval(attrs.ngContextMenu);
//                if (options instanceof Array) {
//                    renderContextMenu($scope, event, options);
//                } else {
//                    throw '"' + attrs.ngContextMenu + '" not an array';                    
//                }
//            });
//        });
//    };
//});
