module.exports = function (models, mailer) {

    var User = models.user;
    var Member = models.member;
    var ProfPosition = models.profPosition;
    var Project = models.project;
    var Lecture = models.lecture;
    var Writing = models.writing;
    var Paper = models.paper;
    var Patent = models.patent;
    var TechTrans = models.techTrans;

    return {
        getMembers: function (req, res) {
            Member.find().find(function (err, members) {
                res.json({members: members});
            });
        },
        getProfPositions: function (req, res) {
            ProfPosition.find().find(function (err, positions) {
                res.json({positions: positions});
            });
        },
        getProjectList: function (req, res) {
            Project.find().find(function (err, projects) {
                res.json({projectlist: projects});
            });
        },
        getYearList: function (req, res) {
            Lecture.aggregate([
                {$match: {$nor: [{year: null}, {year: ''}, {type: 'homework'}]}},
                {$project: {year: 1, semester: 1, _id: 0}},
                {$sort: {semester: -1}},
                {$group: {_id: {year: '$year', semester: '$semester'}}},
                {$group: {_id: '$_id.year', semesters: {$push: '$_id.semester'}}},
                {$sort: {_id: -1}}

            ]).exec(function (err, yearlist) {
                res.json({yearlist: yearlist});
            });
        },
        getLectureList: function (req, res) {
            var lecture = req.body;

            Lecture.aggregate([
                {$match: {year: lecture.year, semester: lecture.semester, type: 'homework'}},
                {$project: {_id: 0, id: 1, title: 1}}
            ]).exec(function (req, lecturelist) {
                res.json({lecturelist: lecturelist});
            });
        },
        getLectureWritingList: function (req, res) {
            var lecture = req.body;

            Writing.aggregate([
                {$match: {id: lecture.id, type: lecture.type, content: {$ne: null}}},
                {$sort: {regdate: -1}}
            ]).exec(function (req, writinglist) {
                res.json({writinglist: writinglist});
            });
        },
        getPaperYearList: function (req, res) {
            Paper.aggregate([
                {$project: {year: 1, type: 1, _id: 0}},
                {$sort: {published: -1}},
                {$group: {_id: {year: '$year', type: '$type'}}},
                {$group: {_id: '$_id.year', type: {$push: '$_id.type'}}},
                {$sort: {_id: -1}}
            ]).exec(function (err, yearlist) {
                res.json({yearlist: yearlist});
            });
        },
        getPaperList: function (req, res) {
            Paper.find().find(function (err, paperlist) {
                res.json({paperlist: paperlist});
            });
        },
        getPatentYearList: function (req, res) {
            Patent.aggregate([
                {$project: {year: 1, _id: 0}},
                {$group: {_id:'$year'}},
                {$sort: {_id: -1}}
            ]).exec(function (err, yearlist) {
                res.json({yearlist: yearlist});
            });
        },
        getPatentList: function (req, res) {
            Patent.aggregate([
                {$match: {patentIdx: null}},
                {$sort: {pubDate: -1}}
            ]).exec(function (err, patentlist) {
                res.json({patentlist: patentlist});
            });
        },
        getTransList: function (req, res) {
            TechTrans.aggregate([
                {$match: {$nor: [{patentIdx: null}, {patentIdx: ''}]}},
                {$sort: {year: -1}}
            ]).exec(function (err, translist) {
                res.json({translist: translist});
            });
        },
        signup: function (req, res) {
            var body = req.body;
            User.findOne({username: body.username
            }, function (err, user) {
                if (err)
                    res.send(500, {'message': err});
                // check to see if theres already a user with that email
                if (user) {
                    res.send(403, {'message': 'User already exist!'});

                } else {
                    var newUser = new User({username: body.username, password: body.password, scope: "student"});
                    if (newUser.username === "admin@lims.com")
                        newUser.scope = "admin";

                    newUser.save(function (err, user) {
                        if (err) {
                            res.send(500, {'message': err});
                        }
                        res.json({'message': 'User was successfully registered!'});
                    });
                }
            });
        },
        login: function (req, res) {
            res.json({email: req.user.email, name: req.user.name, auth_token: req.user.token.auth_token, scope: req.user.scope});
        },
        logout: function (req, res) {
            req.user.auth_token = null;
            req.user.save(function (err, user) {
                if (err) {
                    res.send(500, {'message': err});
                }
                res.json({message: 'See you!'});
            });
        },
        sendEmail: function (req, res) {
            var email = req.body;
            
            User.findOne({email: email.email
            }, function (err, user) {
                if (err)
                    res.send(500, {'message': err});
                if (user) {
                    user.password = email.enc_password;
                    user.save(function (err, user) {
                        if (err) {
                            res.send(500, {'message': err});
                        } else {
                            mailer.sendMail({
                                from: 'ICNS Lab. <admin@icns.khu.ac.kr>',
                                to: email.email,
                                subject: 'hello world!',
                                text: 'Your temporary password is ' + email.password + '</br></br>Please sign in ICNS homepage and change your password.'
                            }, function (err) {
                                if (err) {
                                    console.log(err);
                                    res.send(500, 'There was an error sending the email');
                                } else {
                                    res.send('Email Sent');
                                }
                            });
                        }
                    });

                }
            });


        }

//        getNotice: function(req,res)
//        {
//            Notice.find().sort({reg_date: -1}).find(function(err,notices){
//                res.json({notices: notices });
//            });
//        },
//        writeNotice: function(req,res)
//        {
//            var notice = req.body.notice;
//
//            if (typeof notice.title !== "string") {
//                res.send(400, {'message': "Title must be a string!"});
//            }
//            if (typeof notice.content !== "string") {
//                res.send(400, {'message': "Writer must be a string!"});
//            }
//            
//            var newNotice = new Notice({ title: notice.title, writer: notice.writer, content: notice.content, reg_date: notice.reg_date, hits: 0});
//            newNotice.save(function (err, notice) {
//                if (err){
//                    res.send(500, {'message': err});
//                }
//                res.json({ 'message': 'Notice was successfully added!'});
//            });
//
//        },
//        updateNotice: function(req,res)
//        {
//            
//            var notice = req.body.notice;
//            var _id = notice._id;
//                        
//            var query = { _id: _id };
//            Notice.update(query, {title:notice.title,content:notice.content,hits:notice.hits}, null, function (err, notice) {
//                if (err){
//                    res.send(500, {'message': err});
//                }
//                res.json({ 'message': 'Notice was successfully updated!'});
//            });
//
//        },
//        removeNotice: function(req,res)
//        {
//            var _id = req.params.id;
//
//            Notice.remove({ _id:_id}, function (err, user) {
//                if (err){
//                    res.send(500, {'message': err});
//                }
//                res.json({ 'message': 'Notice was successfully removed!'});
//            })
//
//
//        },
//        createPerson: function(req,res)
//        {
//            var person = req.body.person;
//
//            if (typeof person.name !== "string") {
//                res.send(400, {'message': "Name must be a string!"});
//            }
//            if (typeof person.age !== "number") {
//                res.send(400, {'message': "Age must be a number!"});
//            }
//
//            var newPerson = new Person({ name: person.name, age: person.age})
//            newPerson.save(function (err, user) {
//                if (err){
//                    res.send(500, {'message': err});
//                }
//                res.json({ 'message': 'Person was successfully added!'});
//            });
//
//        },
//        updatePerson: function(req,res)
//        {
//            var _id = req.params.id;
//            var person = req.body.person;
//
//            var query = { _id: _id };
//            Person.update(query, {name:person.name,age:person.age}, null, function (err, thing) {
//                if (err){
//                    res.send(500, {'message': err});
//                }
//                res.json({ 'message': 'Person was successfully updated!'});
//            })
//
//        },
//        removePerson: function(req,res)
//        {
//            var _id = req.params.id;
//
//            Person.remove({ _id:_id}, function (err, user) {
//                if (err){
//                    res.send(500, {'message': err});
//                }
//                res.json({ 'message': 'Person was successfully removed!'});
//            })
//
//
//        },
//        getPeople: function(req,res)
//        {
//
//            Person.find(function(err,people){
//                res.json({people: people });
//            })
//
//
//        },
//        createThing: function(req,res)
//        {
//
//            console.log(req.body);
//            var thing = req.body.thing;
//
//            if (typeof thing.name != "string") {
//                res.send(400, {'message': "Name must be a string!"});
//            }
//            if (typeof thing.size != "number") {
//                res.send(400, {'message': "Size must be a number!"});
//            }
//
//            var newThing = new Thing({ name: thing.name, size: thing.size})
//            newThing.save(function (err, thing) {
//                if (err){
//                    res.send(500, {'message': err});
//                }
//                res.json({ 'message': 'Thing was successfully created!'});
//            });
//
//        },
//        
//        updateThing: function(req,res)
//        {
//            var _id = req.params.id;
//            console.log(req.body);
//            console.log(_id);
//
//            var thing = req.body.thing;
//
//            var query = { _id: _id };
//            Thing.update(query, {name:thing.name,size:thing.size}, null, function (err, thing) {
//                if (err){
//                    res.send(500, {'message': err});
//                }
//                res.json({ 'message': 'Thing was successfully updated!'});
//            })
//
//        },
//        removeThing: function(req,res)
//        {
//            var _id = req.params.id;
//
//            Thing.remove({ _id:_id}, function (err, user) {
//                if (err){
//                    res.send(500, {'message': err});
//                }
//                res.json({ 'message': 'Thing was successfully removed!'});
//            })
//
//        },
//
//        getThings: function(req,res)
//        {
//            Thing.find(function(err,things){
//                res.json({things: things });
//            });
//
//        }


    }

}



