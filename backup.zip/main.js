requirejs.config({
    baseUrl: "/js",
    paths: {
        'app': '../app/app',
        'controller': '../app/controller',
        'directive': '../app/directives',
        'service': '../app/service',
        'filter': '../app/filters',
        'jquery': 'jquery.min',
        'jqueryui': 'jquery-ui.min',
        'mixitup': 'jquery.mixitup.min',
        'movetop': 'move-top',
        'slides': 'responsiveslides.min',
        'easing': 'easing',
        'fancybox': 'fancybox/jquery.fancybox.pack',
        'picasa': 'jquery.picasa.mix',
        'angular': 'angular.min',
        'angularRoute': 'angular-route/angular-route.min',
        'angularLocalStorage': 'angular-local-storage/dist/angular-local-storage.min',
        'angularResource': 'angular-resource.min',
        'cryptojslib': 'cryptojslib/rollups/pbkdf2',
        'bootstrap': 'bootstrap/dist/js/bootstrap.min',
        'lightbox': 'jquery.lightbox_me',
        'pnotify': 'pnotify.custom.min',
        'textAngularRangy': 'textAngular/dist/textAngular-rangy.min',
        'textAngularSanitize': 'textAngular/dist/textAngular-sanitize.min',
        'textAngular': 'textAngular/dist/textAngular.min',
        'zip': 'zip/zip'
//        'dt_jquery': 'datatables/jquery.dataTables',
//        'dt_bootstrap': 'datatables/dataTables.bootstrap',
//        'slimScroll': 'slimScroll/jquery.slimscroll.min',
//        'fastClick': 'fastclick/fastclick.min'
    },
    shim: {
        'jqueryui': ['jquery'],
        'angular': {
            exports: 'angular'
        },
        'angularRoute': ['angular'],
        'angularLocalStorage': ['angular'],
        'angularResource': ['angular'],
        'mixitup': ['jquery'],
        'slides': ['jquery'],
        'movetop': ['jquery'],
        'fancybox': ['jquery'],
        'picasa': ['jquery'],
        'app': ['angular'],
        'bootstrap': ['jquery'],
        'lightbox': ['jquery', 'bootstrap'],
        'easing': ['jquery'],
        'pnotify': ['jquery', 'bootstrap', 'easing'],
        'textAngularSanitize': ['angular', 'angularResource'],
        'textAngular': ['angular', 'angularResource', 'textAngularRangy', 'textAngularSanitize', 'bootstrap']
//        'dt_jquery' : ['jquery'],
//        'dt_bootstrap' : ['jquery', 'bootstrap'],
//        'slimScroll' : ['jquery'],
//        'fastClick' : ['jquery']
    }
    //urlArgs: "bust=v2"
//    urlArgs: "bust=" + (new Date()).getTime()
});

requirejs(['jquery', 'bootstrap', 'jqueryui', 'angular', 'angularRoute', 'angularLocalStorage', 'angularResource', 'cryptojslib', 'controller', 'app',
    'fancybox', 'slides', 'lightbox', 'mixitup', 'movetop', 'picasa', 'easing', 'pnotify', 'textAngularRangy', 'textAngularSanitize', 'textAngular', 'zip'], function () {
    zip.workerScriptsPath = './zip/';
    angular.element(document).ready(function () {
        angular.bootstrap(document, ['mainApp']);
    });
});