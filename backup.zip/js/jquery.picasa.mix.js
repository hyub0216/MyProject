(function ($) {
    $.picasa = {
        recentImages: function (q, count, $filter, callback) {
            var limitTo = $filter('limitTo');

            var url = "https://picasaweb.google.com/data/feed/api/user/114343001404869500164?alt=json&kind=photo&max-results=" + count + "&fields=entry(gphoto:albumid,media:group(media:content,media:description,media:thumbnail))";
            $.getJSON(url, function (data) {
                var albumImage = "";
                $.each(data.feed.entry, function (i, element) {
                    var albumid = element["gphoto$albumid"]["$t"];

                    if (albumid !== "5919335827263646866") {
                        var desc = element["media$group"]["media$description"]["$t"];
                        if (desc.length > 0) {
                            desc = $.parseJSON(desc);
                        } else {
                            desc.title = "title";
                            desc.desc = "desc";
                            desc.date = "date";
                        }

                        var date = desc.date;
                        if (desc.date !== undefined) {
                            var year = desc.date.split('년 ');
                            var mon = year[1].split('월 ');
                            var day = mon[0].split('일')[0];
                            year = year[0];
                            mon = mon[0];
                            date = year + ((mon.length === 1) ? '0' + mon : mon) + ((day.length === 1) ? '0' + day : day);
                        }

                        albumImage += "<div class='meet filter-content app mix " + albumid + "' data-date='" + date + "' style='display: inline-block; opacity: 1;'><div class='filter-wrapper'><a class='grouped_elements' rel='";
                        albumImage += albumid + "' title='" + desc.date + " - " + desc.title + " / " + desc.desc;
                        albumImage += "' href='" + element["media$group"]["media$content"][0]["url"];
                        albumImage += "' target='_blank'><img class='img-responsive' style='width: 268px; height:179px;' src='";
                        albumImage += element["media$group"]["media$thumbnail"][q]["url"];
                        albumImage += "'/></a><div class='meetinfo'><h5>";
                        albumImage += ((desc.title !== undefined && desc.title.toString().length > 18) ? limitTo(desc.title, 16) + '...' : desc.title) + "<br />- " + ((desc.desc !== undefined && desc.desc.toString().length > 11) ? limitTo(desc.desc, 10) + '...' : desc.desc);
                        albumImage += "</h5><p>" + desc.date + "</p></div></div></div>";
                    }
                });
                if (callback) {
                    callback(albumImage);
                }
            });
        },
        recentAlbumImages: function (q, count, album, $filter, callback, finished) {
            var limitTo = $filter('limitTo');

            $.each(album, function (i, element) {
                var url = "https://picasaweb.google.com/data/feed/api/user/114343001404869500164/albumid/" + element + "?alt=json&kind=photo&max-results=" + count + "&fields=entry(gphoto:albumid,media:group(media:content,media:description,media:thumbnail))";
                $.getJSON(url, function (data) {
                    var albumImage = "";
                    $.each(data.feed.entry, function (i, element) {
                        var albumid = element["gphoto$albumid"]["$t"];

                        if (albumid !== "5919335827263646866") {
                            var desc = element["media$group"]["media$description"]["$t"];
                            if (desc.length > 0) {
                                desc = $.parseJSON(desc);
                            } else {
                                desc.title = "title";
                                desc.desc = "desc";
                                desc.date = "date";
                            }

                            var date = desc.date;
                            if (desc.date !== undefined) {
                                var year = desc.date.split('년 ');
                                var mon = year[1].split('월 ');
                                var day = mon[0].split('일')[0];
                                year = year[0];
                                mon = mon[0];
                                date = year + ((mon.length === 1) ? '0' + mon : mon) + ((day.length === 1) ? '0' + day : day);
                            }

                            albumImage += "<div class='meet filter-content app mix " + albumid + "' data-date='" + date + "' style='display: inline-block; opacity: 1;'><div class='filter-wrapper'><a class='grouped_elements' rel='";
                            albumImage += albumid + "' title='" + desc.date + " - " + desc.title + " / " + desc.desc;
                            albumImage += "' href='" + element["media$group"]["media$content"][0]["url"];
                            albumImage += "' target='_blank'><img class='img-responsive' style='width: 268px; height:179px;' src='";
                            albumImage += element["media$group"]["media$thumbnail"][q]["url"];
                            albumImage += "'/></a><div class='meetinfo'><h5>";
                            albumImage += ((desc.title !== undefined && desc.title.toString().length > 18) ? limitTo(desc.title, 16) + '...' : desc.title) + "<br />- " + ((desc.desc !== undefined && desc.desc.toString().length > 11) ? limitTo(desc.desc, 10) + '...' : desc.desc);
                            albumImage += "</h5><p>" + desc.date + "</p></div></div></div>";
                        }
                    });
                    if (callback) {
                        callback(albumImage);
                    }
                });
            });
            if (finished) {
                finished();
            }
        },
        memberImages: function (data, q, callback) {
            var albumImage = "";
            $.each(data, function (i, element) {
                var name = element["name"];
                if (element["nameEng"].length > 1) {
                    name += "</br>(" + element["nameEng"] + ")";
                }
                var email = element["email"];
                if (email.indexOf("test") > -1) {
                    email = "None";
                }
                var pic = element["picture"];
                var course = element["course"];
                var filter = "";
                var align = "";
                if (element["graduate"] === 0) {
                    filter = "alumni";
                    align = '0';
                } else if (course === "Ph.D") {
                    filter = "phd";
                    align = '2';
                } else if (course === "Master") {
                    filter = "master";
                    align = '3';
                } else if (course === "Post Doc.") {
                    filter = "postdoc";
                    align = '1';
                } else {
                    filter = "under";
                    align = '4';
                }

                albumImage += "<div class='member filter-content app mix " + filter + "' data-num='" + pic + "' data-grad='" + element["graduate"] + "' data-course='" + align;
                albumImage += "' style='display: inline-block; opacity: 1;'><div class='filter-wrapper'><a class='grouped_elements' rel='";
                albumImage += filter + "' title='" + course + " " + name + " / " + email;
                albumImage += "' href='/picture/" + pic;
                albumImage += ".jpg' target='_blank'><img class='img-responsive' style='width: 100px; height:140px;' src='/picture/";
                albumImage += pic;
                albumImage += ".jpg'/></a><div class='meminfo'><h5><b>";
                albumImage += course + "</b> " + name;
                albumImage += "</h5><p>" + email + "</p></div></div></div>";
            });
            if (callback) {
                callback(albumImage);
            }
        },
        tempImages: function (q, $filter, callback) {
            var limitTo = $filter('limitTo');

            var url = "https://picasaweb.google.com/data/feed/api/user/114343001404869500164?alt=json&kind=photo&fields=entry(gphoto:albumid,media:group(media:content,media:description,media:thumbnail))";
            $.getJSON(url, function (data) {
                var albumImage = "";
                $.each(data.feed.entry, function (i, element) {
                    var albumid = element["gphoto$albumid"]["$t"];

                    if (albumid !== "5919335827263646866") {
                        var desc = element["media$group"]["media$description"]["$t"];

                        if (desc.length > 0) {
                            desc = $.parseJSON(desc);
                        } else {
                            desc.title = "title";
                            desc.desc = "desc";
                            desc.date = "date";
                        }

                        var date = desc.date;
                        if (desc.date !== undefined) {
                            var year = desc.date.split('년 ');
                            var mon = year[1].split('월 ');
                            var day = mon[0].split('일')[0];
                            year = year[0];
                            mon = mon[0];
                            date = year + ((mon.length === 1) ? '0' + mon : mon) + ((day.length === 1) ? '0' + day : day);
                        }

                        albumImage += "<div class='meet filter-content app mix " + albumid + "' data-date='" + date + "' style='display: inline-block; opacity: 1;'><div class='filter-wrapper'><a class='grouped_elements' rel='";
                        albumImage += albumid + "' title='" + desc.date + " - " + desc.title + " / " + desc.desc;
                        albumImage += "' href='" + element["media$group"]["media$content"][0]["url"];
                        albumImage += "' target='_blank'><img class='img-responsive' style='width: 268px; height:179px;' src='";
                        albumImage += element["media$group"]["media$thumbnail"][q]["url"];
                        albumImage += "'/></a><div class='meetinfo'><h5>";
                        albumImage += ((desc.title !== undefined && desc.title.toString().length > 18) ? limitTo(desc.title, 16) + '...' : desc.title) + "<br />- " + ((desc.desc !== undefined && desc.desc.toString().length > 11) ? limitTo(desc.desc, 10) + '...' : desc.desc);
                        albumImage += "</h5><p>" + desc.date + "</p></div></div></div>";
                    }
                });
                if (callback) {
                    callback(albumImage);
                }
            });
        }
    };
})(jQuery);

//download.js v3.1, by dandavis; 2008-2014. [CCBY2] see http://danml.com/download.html for tests/usage
function download(data,strFileName,strMimeType){var self=window,u="application/octet-stream",m=strMimeType||u,x=data,D=document,a=D.createElement("a"),z=function(a){return String(a)},B=self.Blob||self.MozBlob||self.WebKitBlob||z;B=B.call?B.bind(self):Blob;var fn=strFileName||"download",blob,fr;String(this)==="true"&&(x=[x,m],m=x[0],x=x[1]);if(String(x).match(/^data\:[\w+\-]+\/[\w+\-]+[,;]/))return navigator.msSaveBlob?navigator.msSaveBlob(d2b(x),fn):saver(x);blob=x instanceof B?x:new B([x],{type:m});function d2b(u){var p=u.split(/[:;,]/),t=p[1],dec=p[2]=="base64"?atob:decodeURIComponent,bin=dec(p.pop()),mx=bin.length,i=0,uia=new Uint8Array(mx);for(i;i<mx;++i)uia[i]=bin.charCodeAt(i);return new B([uia],{type:t})}function saver(url,winMode){if("download"in a)return a.href=url,a.setAttribute("download",fn),a.innerHTML="downloading...",D.body.appendChild(a),setTimeout(function(){a.click(),D.body.removeChild(a),winMode===!0&&setTimeout(function(){self.URL.revokeObjectURL(a.href)},250)},66),!0;if(typeof safari!="undefined")return url="data:"+url.replace(/^data:([\w\/\-\+]+)/,u),window.open(url)||confirm("Displaying New Document\n\nUse Save As... to download, then click back to return to this page.")&&(location.href=url),!0;var f=D.createElement("iframe");D.body.appendChild(f),winMode||(url="data:"+url.replace(/^data:([\w\/\-\+]+)/,u)),f.src=url,setTimeout(function(){D.body.removeChild(f)},333)}if(navigator.msSaveBlob)return navigator.msSaveBlob(blob,fn);if(self.URL)saver(self.URL.createObjectURL(blob),!0);else{if(typeof blob=="string"||blob.constructor===z)try{return saver("data:"+m+";base64,"+self.btoa(blob))}catch(y){return saver("data:"+m+","+encodeURIComponent(blob))}fr=new FileReader,fr.onload=function(e){saver(this.result)},fr.readAsDataURL(blob)}return!0}