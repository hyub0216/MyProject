module.exports = function(app) {
  if (!app.mailer) {
    var mailer = require('express-mailer');
    
    console.log('[MAIL] Mailer using user rmcrc.khu@gmail.com');
    return mailer.extend(app, {
      from: 'admin@icns.khu.ac.kr',
      host: 'smtp.gmail.com',
      secureConnection: true,
      port: 465,
      transportMethod: 'SMTP',
      auth: {
        user: 'rmcrc.khu@gmail.com',
        pass: 'rmcrc2013'
      }
    });
  }
};