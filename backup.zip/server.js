/**
 * Module dependencies
 */
var express = require('express');
var mongoose = require('mongoose');
var passport = require('passport');
var http = require('http');
var fs = require('fs');
var path = require('path');
var uuid = require('node-uuid');
var bodyParser = require('body-parser');
var favicon = require('serve-favicon');
var methodOverride = require('method-override');
var cookieParser = require('cookie-parser');
var morgan = require('morgan');
var errorhandler = require('errorhandler');
var session = require('express-session');

var vhost = 'nodejsapp.local';
var port = process.env.PORT || 3000;
var ip = process.env.IP || "localhost";

var app = express();
var connection = require('./config/database')(mongoose);
var models = require('./models/models')(connection);
require('./config/passport')(passport, models); // pass passport for configuration

app.engine('.html', require('ejs').__express);
app.set('port', port);
app.set('view engine', 'html');
app.set('views', __dirname + '/views');
app.use(express.static(__dirname));

app.use(morgan('dev'));

app.use(favicon(__dirname + '/images/favicon.ico'));

app.use(methodOverride('X-HTTP-Method-Override'));
app.set('trust proxy', 1) // trust first proxy

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({'extended': false}));
app.use(cookieParser());
app.use(session({
    secret: 'keyboard cat',
    resave: true,
    saveUninitialized: true,
    cookie: {secure: true}
}));

app.use(passport.initialize());
app.use(passport.session());
//app.route('/index');

var nodemailer = require('nodemailer');
//var generator = require('xoauth2').createXOAuth2Generator({
//    user: '{username}',
//    clientId: '{Client ID}',
//    clientSecret: '{Client Secret}',
//    refreshToken: '{refresh-token}'
//});

// listen for token updates
// you probably want to store these to a db
//generator.on('token', function(token){
//    console.log('New token for %s: %s', token.user, token.accessToken);
//});

// login
var transporter = nodemailer.createTransport(({
    service: 'gmail',
    auth: {
        user: 'rmcrc.khu@gmail.com',
        pass: 'rmcrc2013'
    }
}));


require('./app/routes.js')(app, passport, models, transporter);
// development only
if (app.get('env') === 'development') {
    app.use(errorhandler());
}
;

// production only
if (app.get('env') === 'production') {
// TODO
}
;
app.use(function (req, res, next) {
    console.log(req.path);
});


//var options = {
//  key: fs.readFileSync('./cert/key.pem'),
//  cert: fs.readFileSync('./cert/cert.pem')
//};


//var server = https.createServer(options, app).listen(app.get('port'), function () {
//    console.log('Express server listening on port ' + vhost + ":" + server.address().port);
//});
//












var server = http.createServer(app).listen(app.get('port'), function () {
    console.log('Express server listening on port ' + vhost + ":" + server.address().port);
});








/* patent */

//var mysql = require('mysql');
//
//var sqlConn = mysql.createConnection({
//    host: '163.180.117.240',
//    port: 3306,
//    user: 'root',
//    password: '!icns@322',
//    database: 'ltis'
//});
//
//sqlConn.connect(function (err) {
//    if (err) {
//        console.error('mysql connection error');
//        console.error(err);
//        throw err;
//    }
//});
//
//var query = sqlConn.query('select * from patent left join country on patent.country = country.idx', function (err, rows) {
//    var Patent = models.patent;
//
//    rows.forEach(function (element, index, array) {
//        var patentType = '';
//        switch (element.fcountytype) {
//            case 0:
//                patentType = '국내 출원';
//                break;
//            case 1:
//                patentType = '국내 출원';
//                break;
//            case 2:
//                patentType = 'PCT 해외';
//                break;
//            case 3:
//                patentType = '일반 해외';
//                break;
//        }
//
//        var openStatus = '';
//        switch (element.isPublic) {
//            case 0:
//                openStatus = '공개';
//                break;
//            case 1:
//                openStatus = '공개';
//                break;
//            case 2:
//                openStatus = '비공개';
//                break;
//        }
//
//        var status = '';
//        switch (element.type) {
//            case 0:
//                status = '출원';
//                break;
//            case 1:
//                status = '출원';
//                break;
//            case 2:
//                status = '등록';
//                break;
//            case 3:
//                status = '가출원';
//                break;
//        }
//
//        var ack = new Array();
//
//        var newPatent = new Patent({
//            year: element.year,
//            country: element.code,
//            type: patentType,
//            num: element.patNo,
//            title: element.title,
//            organ: element.organ.replace(/\t/, '').split(/,\s|,|\sand\s/),
//            organNum: element.organNo,
//            pubDate: element.pubdate,
//            openState: openStatus,
//            ack: ack,
//            inventor: element.inventor.replace(/\t/, '').split(/,\s|,|\sand\s/),
//            status: status,
//            file: element.pFile,
//            bTrans: element.techTrans
//        });
//
//        var Project = models.project;
//
//        Project.find({'idx': element.ack}, function (err, ack1) {
//            if (ack1.length > 0) {
//                //console.log('ACK1: ' + ack1[0].ack);
//                newPatent.ack = ack1[0].ack;
//                //console.log(newPaper.ack);
//                newPatent.save(function (err, patent) {
//                    if (err) {
//                        console.log('Error');
//                    }
//                    ;
//                    console.log(patent.num + ' saved');
//                });
//            } else {
//                newPatent.save(function (err, patent) {
//                if (err) {
//                    console.log('Error');
//                }
//                ;
//                console.log(patent.num + ' saved');
//            });
//            }
//            
//        });
//    });
//});

/* tech trans */

//var mysql = require('mysql');
//
//var sqlConn = mysql.createConnection({
//    host: '163.180.117.240',
//    port: 3306,
//    user: 'root',
//    password: '!icns@322',
//    database: 'ltis'
//});
//
//sqlConn.connect(function (err) {
//    if (err) {
//        console.error('mysql connection error');
//        console.error(err);
//        throw err;
//    }
//});
//
//var query = sqlConn.query('select * from patent where techTrans = 1', function (err, rows) {
//    var TechTrans = models.techTrans;
//
//    rows.forEach(function (element, index, array) {
//        var date = element.conDate.split('/');
//        var newTechTrans = new TechTrans({
//            patentIdx: '',
//            title: '',
//            year: element.conYear,
//            country: element.conCountry,
//            preFee: element.preFee,
//            crtFee: element.crtFee,
//            contract: date[0],
//            deposit: date[1],
//            type: element.conType,
//            organ: element.conOrgan,
//            num: element.conNo,
//            gFund: element.conGFund,
//            cFund: element.conCFund,
//            file:''
//        });
//
//        var Patent = models.patent;
//
//        Patent.find({'title': element.title, 'bTrans': 1, 'year': element.year}, function (err, patent) {
//            newTechTrans.patentIdx = patent[0]._id;
//            newTechTrans.title = patent[0].title;
//            
//            newTechTrans.save(function (err, tech) {
//                if (err) {
//                    console.log('Error - ' + err);
//                };
//                console.log(tech.patentIdx);
//            });
//
//        });
//    });
//});


/* paper */

//var mysql = require('mysql');
//
//var sqlConn = mysql.createConnection({
//    host: '163.180.117.240',
//    port: 3306,
//    user: 'root',
//    password: '!icns@322',
//    database: 'ltis'
//});
//
//sqlConn.connect(function (err) {
//    if (err) {
//        console.error('mysql connection error');
//        console.error(err);
//        throw err;
//    }
//});
//
//var query = sqlConn.query('select * from paper left join country on paper.hNation = country.idx', function (err, rows) {
//    var Paper = models.paper;
//
//    rows.forEach(function (element, index, array) {
//        var type = 0;
//        var ack = new Array();
//        switch (element.type) {
//            case 1:
//                type = 'International Jounal,SCI(E)';
//                break;
//            case 2:
//                type = 'International Conference,SCI(E)';
//                break;
//            case 3:
//                type = 'Domestic Jounal';
//                break;
//            case 4:
//                type = 'Domestic Conference';
//                break;
//            case 5:
//                type = 'International Jounal';
//                break;
//            case 6:
//                type = 'International Conference';
//                break;
//        }
//
//        var status = 1;
//        switch (element.pStatus) {
//            case 1:
//                status = 'Submit';
//                break;
//            case 2:
//                status = 'Accepted';
//                break;
//            case 3:
//                status = 'Published';
//                break;
//            case 4:
//                status = 'Online First';
//                break;
//        }
//        
//        var newPaper = new Paper({
//            jTitle: element.jTitle,
//            cTitle: element.cTitle,
//            nation: element.code,
//            status: status,
//            issn: element.issn,
//            iFactor: element.ifactor,
//            pStart: element.pStart,
//            pEnd: element.pEnd,
//            pTitle: element.pTitle,
//            author: element.fAuthor,
//            coAuthor: element.coAuthor.replace(/\t/, '').split(/,\s|,|\sand\s/),
//            published: element.pDate,
//            preDate: element.preDate,
//            vol: element.col,
//            no: element.no,
//            year: (element.year !== '2227')? element.year:'2013',
//            type: type,
//            ack: ack,
//            pFile: element.pFile
//        });
//
//        var Project = models.project;
//
//        Project.find({'idx': element.ack1}, function (err, ack1) {
//            if (ack1.length > 0) {
//                //console.log('ACK1: ' + ack1[0].ack);
//                newPaper.ack.push(ack1[0].ack);
//                Project.find({'idx': element.ack2}, function (err, ack2) {
//                    if (ack2.length > 0) {
//                        //console.log('ACK2: ' + ack2[0].ack);
//                        newPaper.ack.push(ack2[0].ack);
//                    }
//                    //console.log(newPaper.ack);
//                    newPaper.save(function (err, paper) {
//                        if (err) {
//                            console.log('Error');
//                        }
//                        ;
//                        console.log(paper.author + ' saved');
//                    });
//                });
//
//            } else {
//                newPaper.save(function (err, paper) {
//                    if (err) {
//                        console.log('Error');
//                    }
//                    ;
//                    console.log(paper.author + ' saved');
//                });
//            }
//        });
//    });
//});




/* nation */

//var mysql = require('mysql');
//
//var sqlConn = mysql.createConnection({
//    host: '163.180.117.240',
//    port: 3306,
//    user: 'root',
//    password: '!icns@322',
//    database: 'ltis'
//});
//
//sqlConn.connect(function (err) {
//    if (err) {
//        console.error('mysql connection error');
//        console.error(err);
//        throw err;
//    }
//});
//
//var query = sqlConn.query('select * from country', function (err, rows) {
//    var Nation = models.nation;
//
//    rows.forEach(function (element, index, array) {
//        var newNation = new Nation({
//            nation: element.nation,
//            code: element.code
//        });
//
//        newNation.save(function (err, nation) {
//            if (err) {
//                console.log('Error');
//            };
//            console.log(nation.code + ' saved');
//        });
//    });
//});





/* user */

//var mysql = require('mysql');
//
//var sqlConn = mysql.createConnection({
//    host: '163.180.117.240',
//    port: 3306,
//    user: 'root',
//    password: '!icns@322',
//    database: 'new_icns'
//});
//
//sqlConn.connect(function (err) {
//    if (err) {
//        console.error('mysql connection error');
//        console.error(err);
//        throw err;
//    }
//});
//
//var query = sqlConn.query('select * from xe_member', function (err, rows) {
//    var User = models.user;
//
//    rows.forEach(function (element, index, array) {
//        var newUser = new User({
//            email: element.email_address,
//            name: element.nick_name,
//            password: element.password,
//            scope: 'student'
//        });
//
//        if (newUser.email === 'admin@icns.khu.ac.kr')
//            newUser.scope = 'admin';
//
//        newUser.save(function (err, user) {
//            if (err) {
//                console.log('Error');
//            };
//            console.log(user.name + ' saved');
//        });
//    });
//});


/* lecture-board */

//var mysql = require('mysql');
//
//var sqlConn = mysql.createConnection({
//    host: '163.180.117.240',
//    port: 3306,
//    user: 'root',
//    password: '!icns@322',
//    database: 'new_icns'
//});
//
//sqlConn.connect(function (err) {
//    if (err) {
//        console.error('mysql connection error');
//        console.error(err);
//        throw err;
//    }
//});
//
//var query = sqlConn.query('select * from xe_modules where description = "lecture"', function (err, rows) {
//    var Lecture = models.lecture;
//    var Writing = models.writing;
//
//    rows.forEach(function (element, index, array) {
//        var id = element.mid;
//        var type = id.replace(/[a-z]*[a-z]_/gi, '').split('_');
//        var semester = '';
//        var year = '';
//        id = id.replace('_lecture', '');
//        id = id.replace('_Lecture', '');
//        id = id.replace('_homework', '');
//
//        var module = element.module_srl;
//
//        if (id !== 'etc') {
//            semester = type[1];
//            year = type[0];
//            type = type[2];
//        }
//
//
//
//        var newLecture = new Lecture({
//            id: id,
//            year: year,
//            semester: semester,
//            type: type,
//            title: element.browser_title
//        });
//
//        newLecture.save(function (err, lecture) {
//            if (err) {
//                console.log("Error");
//            }
//            //console.log(lecture.id + " saved");
//
//            var secondQ = sqlConn.query('select * from xe_documents where module_srl = "' + module + '"', function (err, rows) {
//                rows.forEach(function (element, index, array) {
//                    var doc_num = element.document_srl;
//                    var up_cnt = element.uploaded_count;
//                    //console.log('doc : ' + doc_num + ', cnt : ' + up_cnt);
//                    if (up_cnt > 0) {
//                        sqlConn.query('select * from xe_files where upload_target_srl = "' + doc_num + '"', function (err, rows) {
//                            var up_list = new Array();
//                            rows.forEach(function (element, index, array) {
//                                var file = {
//                                    filename: element.source_filename,
//                                    path: element.uploaded_filename
//                                }
//                                up_list.push(file);
//                            });
//
//                            var newWriting = new Writing({
//                                id: id,
//                                type: type,
//                                regdate: element.last_update,
//                                name: element.nick_name,
//                                writer: element.email_address,
//                                title: element.title,
//                                content: element.content,
//                                uploaded: JSON.stringify(up_list),
//                                d_count: element.trackback_count,
//                                hit: element.readed_count
//                            });
//
//                            newWriting.save(function (err, writing) {
//                                if (err) {
//                                    console.log("Error");
//                                }
//                                console.log(writing.regdate + " with uploaded files, saved");
//                            });
//                        });
//
//
//                    } else {
//                        var newWriting = new Writing({
//                            id: id,
//                            type: type,
//                            regdate: element.last_update,
//                            name: element.nick_name,
//                            writer: element.email_address,
//                            title: element.title,
//                            content: element.content,
//                            uploaded: new Array(),
//                            d_count: element.trackback_count,
//                            hit: element.readed_count
//                        });
//
//                        newWriting.save(function (err, writing) {
//                            if (err) {
//                                console.log("Error");
//                            }
//                            console.log(writing.regdate + " saved");
//                        });
//                    }
//                });
//            });
//        });
//    });
//});



/* member */

//var mysql = require('mysql');
//
//var sqlConn = mysql.createConnection({
//    host: '163.180.117.240',
//    port: 3306,
//    user: 'root',
//    password: '!icns@322',
//    database: 'icns'
//});
//
//sqlConn.connect(function (err) {
//    if (err) {
//        console.error('mysql connection error');
//        console.error(err);
//        throw err;
//    }
//});
//
//var query = sqlConn.query('select * from member', function (err, rows) {
//    var Member = models.member;
//
//    rows.forEach(function (element, index, array) {
//        var name = element.name.split('(');
//
//        var nameEng = "";
//        if (name.length > 1) {
//            nameEng = name[1].substring(0, name[1].length - 1);
//        }
//        name = name[0];
//
//        var course = "";
//        switch (element.course) {
//            case 0:
//                course = "Post Doc.";
//                break;
//            case 1:
//                course = "Ph.D";
//                break;
//            case 2:
//                course = "Master";
//                break;
//            case 3:
//                course = "Undergraduate";
//                break;
//        }
//        
//        var newMember = new Member({
//            name: name,
//            nameEng: nameEng,
//            course: course,
//            research: "",
//            email: element.email,
//            graduate: element.isGraduate,
//            picture: element.order
//        });
//
//        newMember.save(function (err, member) {
//            if (err) {
//                console.log("Error");
//            }
//            console.log(member.name + " saved");
//        });
//    })
//});

/* professor */

//var data = [
//    {'start': '2011', 'end': '', 'organization': 'Asia-Pacific Advanced Network - Sensor Network Working Group', 'position': 'Group Chair'},
//    {'start': '2011', 'end': '', 'organization': '2011년도 한국 인터넷 정보학회', 'position': '국제 학술 이사'},
//    {'start': '2011', 'end': '', 'organization': '한국 연구재단 국책연구본부 산하 나노융합단', 'position': '전문위원'},
//    {'start': '2011', 'end': '', 'organization': 'Transaction on Internet and Information System', 'position': '국제 논문 편집위원'},
//    {'start': '2011', 'end': '', 'organization': '한국 정보통신 기술협회(TTA) 클라우드 컴퓨팅 프로젝트 그룹', 'position': 'Group Chair'},
//    {'start': '2011', 'end': '', 'organization': 'The Clouds 2011 그랜드 컨퍼런스', 'position': 'Session Chair'},
//    {'start': '2011', 'end': '', 'organization': 'ISO/IEC JTC1 SC38 총회', 'position': '한국 대표 위원'},
//    {'start': '2011', 'end': '', 'organization': '2011년도 한국 인터넷 정보 학회', 'position': '학회 운영 이사'},
//    {'start': '2010', 'end': '2010', 'organization': '한국인터넷 정보 학회', 'position': '국제 논문 편집위원(SCIE)'},
//    {'start': '2010', 'end': '2010', 'organization': '개방형 컴퓨터 통신 연구회', 'position': '조직위원회 위원'},
//    {'start': '2010', 'end': '2010', 'organization': '한국 연구재단 국책연구본부 산하 나노융합단', 'position': '전문위원'},
//    {'start': '2010', 'end': '2010', 'organization': '한국 정보화 진흥원 KOREN Workshop 2010', 'position': 'Session Chair'},
//    {'start': '2010', 'end': '2010', 'organization': '2010년도 한국 정보처리 학회', 'position': '학회 이사'},
//    {'start': '2009', 'end': '2009', 'organization': '2009년도 한국 인터넷 정보 학회', 'position': '학회 이사'},
//    {'start': '2009', 'end': '2009', 'organization': '2009년도 한국 정보처리 학회', 'position': '학회 이사'},
//    {'start': '2009', 'end': '2009', 'organization': 'ICCSA 2009', 'position': 'Financial chair'},
//    {'start': '2009', 'end': '2009', 'organization': 'HSN 2009', 'position': '운영위원회 위원'},
//    {'start': '2009', 'end': '2009', 'organization': 'IT21 Conference', 'position': '학술위원회 위원'},
//    {'start': '2009', 'end': '2009', 'organization': '한국 정보화 진흥원 KOREN Workshop 2009', 'position': '운영 위원'},
//    {'start': '2008', 'end': '2008', 'organization': '2009년도 한국 정보 과학회', 'position': 'Session Chair'},
//    {'start': '2008', 'end': '2008', 'organization': '2008 한국 인터넷 정보학회 추계 학술대회', 'position': '조직위원회 위원'},
//    {'start': '2008', 'end': '2008', 'organization': '프로그램위원회', 'position': '조직위원회 위원'},
//    {'start': '2008', 'end': '2008', 'organization': '2008 한국 인터넷 정보학회 추계 학술대회', 'position': '조직위원회 위원'},
//    {'start': '2008', 'end': '2008', 'organization': '연천군지역정보화촉진협의회', 'position': '협의회 위원'},
//    {'start': '2008', 'end': '2008', 'organization': '한국전자통신연구원, 한국 RFID/USN 협회', 'position': '프로그램위원회 위원'},
//    {'start': '2008', 'end': '2008', 'organization': 'The 2008 International Conference on Computational Science and ITS Applications', 'position': 'Session Chair, 학회 임원'},
//    {'start': '2008', 'end': '2008', 'organization': '2008년도 IT21 컨퍼런스', 'position': '학술위원회 위원'},
//    {'start': '2008', 'end': '2008', 'organization': '2008 임시총회 및 춘계학술발표대회', 'position': '조직위원회 위원'},
//    {'start': '2008', 'end': '2008', 'organization': '제29회 한국정보처리학회 춘계학술발표대회', 'position': '학술위원회 부위원장'},
//    {'start': '2008', 'end': '2008', 'organization': '제13회 정보통신응용기술워크숍', 'position': '프로그램위원회 위원'},
//    {'start': '2008', 'end': '2009', 'organization': '2008년도 한국정보처리학회', 'position': '학회 이사'},
//    {'start': '2008', 'end': '2008', 'organization': '학회 대외협력위원회 국제 협력위원회', 'position': '협력위원회 위원'},
//    {'start': '2007', 'end': '2007', 'organization': 'Korea Internet Conference 2007 (KRnet 2007) 운영위원회', 'position': '현장위원'},
//    {'start': '2007', 'end': '2007', 'organization': '한국정보처리학회 춘계학술발표대회', 'position': '학술위원'},
//    {'start': '2007', 'end': '2007', 'organization': '한국정보처리학회', 'position': '대외협력 이사'},
//    {'start': '2007', 'end': '2007', 'organization': '한국인터넷정보학회', 'position': '5대 논문지 편집위원'},
//    {'start': '2007', 'end': '2007', 'organization': '외교통상부 자체평가위원회', 'position': '위원'},
//    {'start': '2007', 'end': '2007', 'organization': '외교통상부 외교정보화추진분과	', 'position': '분과위원'},
//    {'start': '2007', 'end': '2007', 'organization': '경희대학교 컴퓨터공학과 삼성 정보통신트랙 운영위원회', 'position': '간사'},
//    {'start': '2007', 'end': '2007', 'organization': '경희대학교 공학교육 혁신센터', 'position': '자체평가위원'},
//    {'start': '2007', 'end': '2007', 'organization': 'International Conference on Computational Science and its Application(ICCSA)', 'position': 'Session Chair'},
//    {'start': '2006', 'end': '2006', 'organization': 'Grid@Asia GFK2006 International Joint Workshop', 'position': '프로그램위원회 위원장'},
//    {'start': '2006', 'end': '2006', 'organization': 'International Workshop on Information Security Applications', 'position': 'Session Chair'},
//    {'start': '2006', 'end': '2006', 'organization': 'Grid Forum Korea 2006', 'position': '프로그램위원회 위원'},
//    {'start': '2006', 'end': '2006', 'organization': '동북아시아 정보과학 기술교류 국제학술대회', 'position': '조직위원회 위원장'},
//    {'start': '2006', 'end': '2006', 'organization': 'ICAT 2006', 'position': '운영위원회 위원장 및 프로그램 위원회 위원'},
//    {'start': '2006', 'end': '2006', 'organization': '한국 인터넷 정보학회', 'position': '조직위원회 위원'},
//    {'start': '2005', 'end': '2005', 'organization': '국무조정실', 'position': '국가 부처 정보화 수준 평가위원'},
//    {'start': '2005', 'end': '2005', 'organization': '한국정보통신기술협회', 'position': '표준화 그룹 의장'},
//    {'start': '2005', 'end': '2005', 'organization': '한국인터넷정보학회', 'position': '논문집 편집위원'},
//    {'start': '2005', 'end': '2005', 'organization': '한국 정보처리학회 ICAT 2005', 'position': '프로그램 위원장'}];
//
//var ProfPosition = models.profPosition;
//data.forEach(function (element, index, array) {
//
//    var newPosition = new ProfPosition({
//        start: element.start,
//        end: element.end,
//        organization: element.organization,
//        position: element.position
//    });
//    newPosition.save(function (err, position) {
//        if (err) {
//            console.log("Error");
//        }
//        console.log(position.position + " saved");
//    });
//});


/* project */

//var mysql = require('mysql');
//
//var sqlConn = mysql.createConnection({
//    host: '163.180.117.240',
//    port: 3306,
//    user: 'root',
//    password: '!icns@322',
//    database: 'ltis'
//});
//
//sqlConn.connect(function (err) {
//    if (err) {
//        console.error('mysql connection error');
//        console.error(err);
//        throw err;
//    }
//});
//
//var query = sqlConn.query('select * from project', function (err, rows) {
//    var Project = models.project;
//
//    rows.forEach(function (element, index, array) {
//        var s = new Date(element.sPeriod).toISOString();
//        if (s.length > 0) {
//            s = s.split('T')[0].replace('-', '.');
//        }
//        var e = new Date(element.ePeriod).toISOString();
//        if (e.length > 0) {
//            e = e.split('T')[0].replace('-', '.');
//        }
//        var newProject = new Project({
//            idx: element.idx,
//            start: s,
//            end: e,
//            title: element.projName,
//            organ: element.organ,
//            total_fund: element.tFund,
//            assign_fund: element.assignFund,
//            ack: element.ack,
//            ack_ko: element.ackKo,
//            ack_eng: element.ackEn
//        });
//
//        newProject.save(function (err, project) {
//            if (err) {
//                console.log("Error");
//            }
//            console.log(project.title + " saved");
//        });
//    })
//});